import { PlantData } from "../types";

export interface SamplePlant {
  id: string;
  name: string;
  scientific: string;
  family: string;
  difficulty: "Easy" | "Medium" | "Hard";
  iconName: string;
  svgMarkup: string;
  plantData: PlantData;
}

// Inline SVGs representing beautiful, modern minimalist plants for our Aurora UI
export const SAMPLES: SamplePlant[] = [
  {
    id: "sample-monstera",
    name: "Monstera Deliciosa",
    scientific: "Monstera deliciosa",
    family: "Araceae",
    difficulty: "Medium",
    iconName: "Leaf",
    svgMarkup: `<svg viewBox="0 0 200 200" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="aurora-bg-1" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#22c55e" stop-opacity="0.25"/>
          <stop offset="100%" stop-color="#052e16" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="50%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#15803d" />
        </linearGradient>
        <linearGradient id="potGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#fdd8e5" />
          <stop offset="100%" stop-color="#f472b6" />
        </linearGradient>
      </defs>
      <circle cx="100" cy="110" r="85" fill="url(#aurora-bg-1)" />
      
      <!-- Stems -->
      <path d="M100,165 Q70,90 40,70" stroke="#15803d" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M100,165 Q100,100 110,60" stroke="#15803d" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M100,165 Q115,110 150,85" stroke="#16a34a" stroke-width="3.5" fill="none" stroke-linecap="round"/>
      <path d="M100,165 Q125,120 160,115" stroke="#16a34a" stroke-width="3" fill="none" stroke-linecap="round"/>
      
      <!-- Leaf 1 (Left Split Leaf) -->
      <g transform="translate(40, 70) rotate(-45)">
        <path d="M0,0 Q-35,-20 -20,-50 Q-10,-60 20,-45 Q40,-30 0,0" fill="url(#leafGrad)" />
        <path d="M0,0 Q25,-15 15,-45 Q5,-55 -20,-35 Z" fill="url(#leafGrad)" />
        <!-- Splits -->
        <path d="M-15,-25 L-35,-30" stroke="#052e16" stroke-width="1.5" />
        <path d="M-18,-38 L-38,-42" stroke="#052e16" stroke-width="1.5" />
        <path d="M-5,-42 L-22,-52" stroke="#052e16" stroke-width="1.5" />
        <path d="M12,-30 L28,-36" stroke="#052e16" stroke-width="1.5" />
      </g>
      
      <!-- Leaf 2 (Center) -->
      <g transform="translate(110, 60) rotate(-10)">
        <path d="M0,0 Q-25,-30 -5,-60 Q10,-70 30,-40 Q40,-15 0,0" fill="url(#leafGrad)" />
        <path d="M-5,-35 L-22,-45" stroke="#052e16" stroke-width="1.5" />
        <path d="M8,-48 L1,-61" stroke="#052e16" stroke-width="1.5" />
        <path d="M22,-32 L38,-38" stroke="#052e16" stroke-width="1.5" />
      </g>
      
      <!-- Leaf 3 (Right) -->
      <g transform="translate(150, 85) rotate(25)">
        <path d="M0,0 Q-20,-30 10,-55 Q25,-60 35,-30 Q35,5 0,0" fill="url(#leafGrad)" />
        <path d="M-5,-25 L-20,-32" stroke="#052e16" stroke-width="1.5" />
        <path d="M10,-42 L5,-57" stroke="#052e16" stroke-width="1.5" />
        <path d="M25,-25 L38,-28" stroke="#052e16" stroke-width="1.5" />
      </g>
      
      <!-- Pot -->
      <ellipse cx="100" cy="165" rx="35" ry="8" fill="#1e293b" />
      <path d="M65,165 L72,192 Q100,198 128,192 L135,165 Z" fill="url(#potGrad)" />
      <ellipse cx="100" cy="192" rx="28" ry="6" fill="#be185d" opacity="0.3"/>
    </svg>`,
    plantData: {
      commonName: "Monstera Deliciosa",
      scientificName: "Monstera deliciosa",
      family: "Araceae",
      confidence: 98,
      difficulty: "Medium",
      toxicity: "Toxic to cats and dogs (contains calcium oxalate crystals which cause intense mouth irritation and swelling).",
      description: "Known as the Swiss Cheese Plant, this stunning tropical native is beloved for its iconic leaf fenestrations (natural splits) and dramatic tropical statement. It brings an instant lush jungle vibe into any modern room alignment.",
      watering: {
        frequency: "Every 7-10 days",
        details: "Water thoroughly when the top 5-7cm (2-3 inches) of soil becomes completely dry to the touch. Ensure excellent drainage from the bottom of the pot to avert root rot. Drooping leaves can signal thirst, while sweat-like droplets on leaf tips show waterlogged saturation."
      },
      sunlight: {
        quality: "Bright, indirect sunlight",
        details: "Place near a east or west facing window, shielded from scorching direct beams which bleach the glossy dark green pigmentation. Tolerant to medium ambient light but growth rate will decrease and leaves won't develop fenestrations."
      },
      temperature: {
        range: "15°C - 30°C (60°F - 85°F)",
        details: "Thrives in warm indoor climates. Avoid placing near cold window draft lines or air conditioning output vents. Guard against cold drops below 10°C."
      },
      humidity: {
        level: "High",
        details: "Prefers elevated humidity above 50-60%. In dry rooms, group with other plants, run a workspace humidifier, or prop onto a wet pebble tray. Gently wipe large leaves with a moist microfiber cloth weekly to clear dust and improve breathability."
      },
      soil: {
        type: "Peaty, orchid-bark aerated potting mix",
        details: "Requires rich organic soil packed with perlite, peat moss, and pine orchid bark. This mimics the aerated jungle floor, letting roots breathe securely without swampy compaction."
      },
      fertilizing: {
        frequency: "Once a month during spring and summer",
        details: "Apply a balanced liquid fertilizer diluted to half-strength. Refrain from feeding during the winter dormancy period when active growth pauses."
      },
      careSchedule: [
        { action: "Watering", frequency: "Weekly", instructions: "Touch soil 5cm deep. If dry, pour water evenly until it trickles out the drainage pot base." },
        { action: "Sponge Cleanse", frequency: "Bi-weekly", instructions: "Wipe both sides of leaves with a soft damp cloth to maximize photosynthesis capability." },
        { action: "Fertilizing", frequency: "Monthly", instructions: "Mix organic seaweed/balanced fluid fertilizer with water at 50% ratio and feed plant." }
      ],
      commonProblems: [
        { problem: "Yellowing Lower Leaves", symptom: "Lower leaves turn a mushy pale yellow and stems lose rigidity.", solution: "Classic sign of overwatering. Immediately cease watering, check pot drainage, and allow potting soil to air-dry fully." },
        { problem: "Brown Crunchy Tips", symptom: "Leaf points and edges turn dry, crisp, and brittle brown.", solution: "Low workspace humidity or dry air. Mist active foliage, deploy a pebble tray humidifier, and check soil to make sure it is not chronically bone-dry." }
      ],
      tips: [
        "Incorporate a moss pole or wooden trellis! Monsteras are natural epiphytic climbers and will reward you with massive, split leaves as they grow upwards.",
        "Rotate the pot 90 degrees every month. This ensures even sunlight distribution, preventing the plant from leaning lopsidedly towards light sources."
      ]
    }
  },
  {
    id: "sample-snake",
    name: "Snake Plant",
    scientific: "Sansevieria trifasciata",
    family: "Asparagaceae",
    difficulty: "Easy",
    iconName: "Maximize2",
    svgMarkup: `<svg viewBox="0 0 200 200" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="aurora-bg-2" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#fb923c" stop-opacity="0.2"/>
          <stop offset="100%" stop-color="#7c2d12" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="snakeLeaf" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#065f46" />
          <stop offset="25%" stop-color="#10b981" />
          <stop offset="50%" stop-color="#047857" />
          <stop offset="75%" stop-color="#059669" />
          <stop offset="100%" stop-color="#065f46" />
        </linearGradient>
        <linearGradient id="yellowBorder" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#f59e0b" />
          <stop offset="100%" stop-color="#65a30d" />
        </linearGradient>
        <linearGradient id="potGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#93c5fd" />
          <stop offset="100%" stop-color="#2563eb" />
        </linearGradient>
      </defs>
      <circle cx="100" cy="110" r="85" fill="url(#aurora-bg-2)" />
      
      <!-- Snake plant leaves (long blade swords) -->
      <!-- Leaf Back Left -->
      <path d="M75,160 Q55,90 75,45 Q88,80 82,160" fill="url(#snakeLeaf)" stroke="url(#yellowBorder)" stroke-width="2"/>
      
      <!-- Leaf Back Right -->
      <path d="M115,160 Q135,100 120,55 Q105,95 110,160" fill="url(#snakeLeaf)" stroke="url(#yellowBorder)" stroke-width="2"/>
      
      <!-- Leaf Tall Center -->
      <path d="M96,160 Q85,70 98,25 Q115,70 102,160" fill="url(#snakeLeaf)" stroke="url(#yellowBorder)" stroke-width="2.5"/>
      
      <!-- Leaf Front Left -->
      <path d="M85,160 Q70,110 88,75 Q96,110 92,160" fill="url(#snakeLeaf)" stroke="url(#yellowBorder)" stroke-width="1.8"/>

      <!-- Leaf Front Right -->
      <path d="M106,160 Q122,120 108,85 Q98,120 102,160" fill="url(#snakeLeaf)" stroke="url(#yellowBorder)" stroke-width="1.8"/>

      <!-- Pot -->
      <ellipse cx="100" cy="160" rx="30" ry="8" fill="#0f172a" />
      <path d="M70,160 L76,190 Q100,196 124,190 L130,160 Z" fill="url(#potGrad2)" />
      <ellipse cx="100" cy="190" rx="24" ry="5" fill="#1d4ed8" opacity="0.3"/>
    </svg>`,
    plantData: {
      commonName: "Snake Plant",
      scientificName: "Sansevieria trifasciata",
      family: "Asparagaceae",
      confidence: 99,
      difficulty: "Easy",
      toxicity: "Toxic to dogs and cats (contains saponins which cause mild gastrointestinal symptoms, drooling, and vomiting).",
      description: "Affectionately referred to as Mother-in-Law's Tongue, the Snake Plant is the ultimate structural sentinel. Featuring upright, sword-shaped leaves with golden-yellow margins, it is legendarily indestructible and acts as a fantastic natural air purifier capable of producing oxygen during night hours.",
      watering: {
        frequency: "Every 2-4 weeks",
        details: "The gold standard rule: 'When in doubt, don't water.' Let the soil dry completely from root to surface before watering again. During cold winter spells, water only once or twice, as sluggish leaves easily rot at the base if left damp."
      },
      sunlight: {
        quality: "Highly adaptable (Tolerates low to bright, indirect light)",
        details: "Thrives in almost any light profile. It will survive comfortably in low dark corners of your apartment, but will register faster, more vibrant growth and brighter golden margins under indirect bright setups."
      },
      temperature: {
        range: "12°C - 32°C (55°F - 90°F)",
        details: "Extremely resilient. However, keep shielded from hard freezing weather below 10°C, which triggers structural collapsing of succulent cells."
      },
      humidity: {
        level: "Low to Average",
        details: "Normal home air is completely fine. Avoid humid bathroom corners or constant direct water spraying; damp leaf crevasses can host fungal root infestations."
      },
      soil: {
        type: "Sandy Cactus-Succulent Mix",
        details: "Requires free-draining sandy/rocky potting soil. A standard cactus substrate fortified with extra pumice or perlite prevents any accidental waterlogged stagnation."
      },
      fertilizing: {
        frequency: "Twice a year",
        details: "Feed once in high spring and once in mid summer using mild cactus liquid plant food. Refrain from feeding during fall and winter months."
      },
      careSchedule: [
        { action: "Watering", frequency: "Bi-weekly / Monthly", instructions: "Check soil deep down. Water only if soil feels like bone-dry desert sand." },
        { action: "Leaf Dusting", frequency: "Monthly", instructions: "Wipe flat blades with dry microfiber fabric to preserve their green glowing stripe patterns." },
        { action: "Drainage Check", frequency: "Ongoing", instructions: "Verify that zero excess moisture pool accumulates in the bottom pot saucer." }
      ],
      commonProblems: [
        { problem: "Wrinkled, Drooping Leaves", symptom: "Leaf blades bend, lose structural rigidity, or show prune-like wrinkles.", solution: "Underwatering. Though drought-resistant, the plant will eventually exhaust its storage. Give a thorough deep soak and it will plump back up over 48 hours." },
        { problem: "Mushy Base", symptom: "Grass-green base stems turn soggy, dark, and collapse onto the floor.", solution: "Severe root rot from excess watering. Immediately slice away mushy leaves, repot surviving stems into fresh dry cactus soil, and clip off infected black roots." }
      ],
      tips: [
        "Select heavy terracotta pots! Ceramic or clay pots breathe better than plastic, preventing moisture traps, and stop the tall heavy leaves from toppling the pot over.",
        "Propagate via leaf cuttings in water! Simply chop a healthy leaf into 10cm chevron-notched slices, place in water, and watch solid white roots pop out in weeks."
      ]
    }
  },
  {
    id: "sample-succulent",
    name: "Echeveria Succulent",
    scientific: "Echeveria elegans",
    family: "Crassulaceae",
    difficulty: "Easy",
    iconName: "Compass",
    svgMarkup: `<svg viewBox="0 0 200 200" class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="aurora-bg-3" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#22d3ee" stop-opacity="0.25"/>
          <stop offset="100%" stop-color="#083344" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="petalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#a7f3d0" />
          <stop offset="50%" stop-color="#2dd4bf" />
          <stop offset="100%" stop-color="#0891b2" />
        </linearGradient>
        <linearGradient id="potGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#fbcfe8" />
          <stop offset="100%" stop-color="#ec4899" />
        </linearGradient>
      </defs>
      <circle cx="100" cy="110" r="85" fill="url(#aurora-bg-3)" />
      
      <!-- Succulent Rosette Petals (Radial Symmetric Petals) -->
      <g transform="translate(100, 140)">
        <!-- Outer layer -->
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(0)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(45)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(90)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(135)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(180)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(225)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(270)"/>
        <path d="M0,0 Q-40,-35 0,-60 Q40,-35 0,0" fill="url(#petalGrad)" stroke="#0e7490" stroke-width="1" transform="rotate(315)"/>
        
        <!-- Inner Layer (Pink Tip Glow) -->
        <g scale="0.7">
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#a7f3d0" stroke="#fb7185" stroke-width="1.2" transform="rotate(22)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#2dd4bf" stroke="#fb7185" stroke-width="1.2" transform="rotate(67)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#0891b2" stroke="#fb7185" stroke-width="1.2" transform="rotate(112)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#2dd4bf" stroke="#fb7185" stroke-width="1.2" transform="rotate(157)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#a7f3d0" stroke="#fb7185" stroke-width="1.2" transform="rotate(202)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#2dd4bf" stroke="#fb7185" stroke-width="1.2" transform="rotate(247)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#0891b2" stroke="#fb7185" stroke-width="1.2" transform="rotate(292)"/>
          <path d="M0,0 Q-25,-25 0,-45 Q25,-25 0,0" fill="#2dd4bf" stroke="#fb7185" stroke-width="1.2" transform="rotate(337)"/>
        </g>
      </g>

      <!-- Pot (Small stylish saucer bowl) -->
      <path d="M55,160 L60,185 Q100,192 140,185 L145,160 Z" fill="url(#potGrad3)" />
      <ellipse cx="100" cy="160" rx="45" ry="5" fill="#475569" />
      <ellipse cx="100" cy="185" rx="36" ry="4" fill="#db2777" opacity="0.25"/>
    </svg>`,
    plantData: {
      commonName: "Echeveria Succulent",
      scientificName: "Echeveria elegans",
      family: "Crassulaceae",
      confidence: 96,
      difficulty: "Easy",
      toxicity: "Non-toxic and perfectly safe for cats, dogs, and children.",
      description: "Sometimes called Mexican Snowball, this adorable desert native develops a tight rose-shaped rosette of plump, fleshy, pale-blue leaves. In cold weather or under high sun exposure, the tips catch a breathtaking peach-pink border glow.",
      watering: {
        frequency: "Every 10-14 days",
        details: "Employ the soak-and-dry watering protocol. Drench the pot until water floods out, then do not water again until soil is completely dry from bottom to top. Never pour water inside the center rosette cup; stagnant water trapped within leaves breeds devastating rot."
      },
      sunlight: {
        quality: "Bright, direct sunlight (4-6 hours daily)",
        details: "Thrives on sun-drenched south or west windowsills. If it gets too little light, the gorgeous radial rosette starts stretching out, losing its tight shape and pale glow, a phenomenon called 'etiolation'."
      },
      temperature: {
        range: "10°C - 27°C (50°F - 80°F)",
        details: "Comfortable in house ambient warmth. Avoid extreme frost exposures below 4°C, which freeze water inside succulent tissue, bursting the cells."
      },
      humidity: {
        level: "Low",
        details: "Appreciates highly arid, well-ventilated locations. Do not mist or place in steamy bathrooms; succulent leaves absorb humidity, making them mushy."
      },
      soil: {
        type: "Coarse Sandy Cactus/Succulent Mix",
        details: "Requires rapid drain speeds. Blend 50% regular potting soil with 50% coarse horticultural sand, pumice, or fine gravel to guarantee water cannot stagnate."
      },
      fertilizing: {
        frequency: "Once a year",
        details: "Feed once during early spring using diluted low-nitrogen succulent plant food. Succulents are natural low-nutritional survivors."
      },
      careSchedule: [
        { action: "Watering", frequency: "Every 10 days", instructions: "Give a full drench. Do not spray leaves with a mister." },
        { action: "Sunbath rotate", frequency: "Weekly", instructions: "Turn the pot 180 degrees weekly for uniform rosette development." },
        { action: "Pruning", frequency: "Ongoing", instructions: "Gently pluck off dry shriveled lower leaves from the very bottom stem." }
      ],
      commonProblems: [
        { problem: "Etiolation / Stretching", symptom: "Rosette grows tall, lanky, with large spacing between leaves, turning pale.", solution: "Insufficient light. Move the succulent to the brightest available windowsill immediately. In severe cases, chop off the top rosette and propagate it." },
        { problem: "Translucent Soft Leaves", symptom: "Leaves turn waterlogged, mushy, pale-yellow, and fall off easily.", solution: "Excessive water. Halt watering, let the pot dry in hot sun, and inspect base root health for black root decay." }
      ],
      tips: [
        "Propagate from a single leaf! Snap a leaf off cleanly (the entire leaf petiole must come off), let the wound callus dry for 3 days, lay it on flat succulent soil, and simple, baby rose-buds will sprout.",
        "Refrain from touching leaf surfaces! High quality Echeverias grow a protective silvery wax coating called 'farina' which protects them from direct sun sunburn."
      ]
    }
  }
];

// High-quality Korean translated sample plant templates
export const KOREAN_SAMPLES_MAP: Record<string, PlantData> = {
  "Monstera deliciosa": {
    commonName: "몬스테라 (스위스 치즈 식물)",
    scientificName: "Monstera deliciosa",
    family: "Araceae (천남성과)",
    confidence: 98,
    difficulty: "Medium",
    toxicity: "고양이와 개에게 독성이 있습니다 (입안에 강한 자극과 부종을 유발하는 옥살산 칼슘 결정 포함).",
    description: "스위스 치즈 식물로 잘 알려진 이 아름다운 열대 자생 식물은 상징적인 잎의 구멍(갈라짐)과 극적인 열대적 연출로 널리 사랑받고 있습니다. 현대적인 실내 공간에 배치하면 아늑한 정글 분위기를 연출할 수 있습니다.",
    watering: {
      frequency: "7-10일 간격",
      details: "흙 표면으로부터 약 5-7cm 깊이까지 만졌을 때 완전히 보송하게 말랐을 때 흠뻑 물을 줍니다. 화분 바닥의 배수 구멍이 원활히 뚫려 있는지 확인해야 뿌리 부패를 막을 수 있습니다. 잎이 아래로 처지는 것은 목마름의 신호이며, 잎끝에 물방울이 맺히는 일액현상은 과습 상태를 나타냅니다."
    },
    sunlight: {
      quality: "밝은 간접 광원",
      details: "동쪽이나 서쪽 창문 근처에 놓되, 은은한 간접 자연광 아래가 제일 좋습니다. 잎이 타들어 가거나 탈색되지 않도록 뜨거운 직사광선은 피해 주십시오. 보통의 낮은 조도 환경에서도 견디지만 성장 속도가 매우 저하되며 잎의 구멍이 정상적으로 벌어지지 않을 수 있습니다."
    },
    temperature: {
      range: "15°C - 30°C (60°F - 85°F)",
      details: "따뜻한 실내 환경에서 아주 잘 자랍니다. 찬바람이 부는 창틀 틈새나 에어컨 송풍구 근처에 두지 않도록 주의하고, 10°C 미만으로 기온이 급감하는 것을 막아야 합니다."
    },
    humidity: {
      level: "높음",
      details: "50-60% 이상의 높은 상대 습도를 매우 선호합니다. 건조한 실내에서는 식물끼리 모아 배치하거나, 가습기를 가동하거나, 물이 담긴 자갈 트레이 위에 분을 올려두세요. 매주 잎 앞뒷면을 부드럽고 젖은 극세사 천으로 닦아 먼지를 털어내면 숨쉬기와 광합성에 아주 이롭습니다."
    },
    soil: {
      type: "피트머스, 바크가 섞여 배수가 잘되는 용토",
      details: "펄라이트, 피트머스, 소나무 바크 등으로 구성되어 유기질이 풍부하고 기공이 넓은 흙이 이상적입니다. 이는 비가 자주 오고 배수가 즉각적으로 이루어지는 열대 우림의 지표층을 모방하여, 뿌리가 질식하지 않고 숨을 쉴 수 있게 도와줍니다."
    },
    fertilizing: {
      frequency: "봄과 여름 동안 한 달에 한 번",
      details: "희석한 범용 액체 비료를 표준 기준의 절반 강도로 시비합니다. 전반적인 생장이 느려지는 겨울철 휴면기에는 시비를 완전히 중단하십시오."
    },
    careSchedule: [
      { action: "물주기", frequency: "매주", instructions: "흙 표면 아래 5cm 부근을 만져보아 건조하다면 배수구 밑으로 물이 흘러나올 때까지 골고루 흠뻑 적셔 줍니다." },
      { action: "잎사귀 정돈", frequency: "2주 간격", instructions: "젖은 수건 등으로 잎사귀 표면의 먼지를 정성스럽게 닦아주어 광합성을 극대화합니다." },
      { action: "비료 공급", frequency: "매월", instructions: "영양가 높은 유기농 해조 비료 또는 액체 비료를 약 50% 농도로 약하게 희석하여 흙에 공급합니다." }
    ],
    commonProblems: [
      { problem: "하단 하엽 황화 현상", symptom: "아래쪽 잎사귀가 연약한 노란색으로 변하며 줄기가 무기력하게 힘을 잃습니다.", solution: "전형적인 과습 및 배수 불량의 증상입니다. 즉각 물주기를 전면 중단하고 화분 배수상태를 개선하며 화분 내 흙이 충분히 마를 때까지 기다려줍니다." },
      { problem: "갈색 마른 잎끝 현상", symptom: "잎사귀 끝부분과 일부분 테두리가 마치 바삭거리는 과자처럼 마르고 타들어 갑니다.", solution: "실내 공기가 너무 건조할 때 발생합니까. 잎 분무를 실시하거나, 가습 공조 시설을 키우고, 흙이 장기간 바짝 마른 채 방치되지 않았는지 점검해 보세요." }
    ],
    tips: [
      "수태봉이나 격자 기둥을 설치해 주세요! 몬스테라는 기근을 내려 나무를 타는 덩굴성 착생 식물이기 때문에 상단으로 유인 배양할수록 훨씬 크고 멋진 구멍 잎을 선물합니다.",
      "한 달에 한 번씩 화분을 90도씩 회전시켜 주세요. 이를 통해 자연광을 골고루 받아 한쪽으로만 기울어지는 기형적인 수형 발달을 예방할 수 있습니다."
    ]
  },
  "Sansevieria trifasciata": {
    commonName: "산세베리아 (스네이크 플랜트)",
    scientificName: "Sansevieria trifasciata",
    family: "Asparagaceae (백합과)",
    confidence: 100,
    difficulty: "Easy",
    toxicity: "개와 고양이에게 약한 독성이 있습니다 (가벼운 소화기 장애, 침 흘림, 구토를 유발할 수 있는 사포닌 성분 함유).",
    description: "시어머니의 등뼈, 또는 호랑이 꼬리를 닮았다고 하여 '호접란'처럼 강건한 검 형태를 자랑하는 실내 공기 정화의 왕입니다. 밤사이에 다량의 이산화탄소를 흡수하고 깨끗한 산소를 집중적으로 배출하는 밤의 천사입니다.",
    watering: {
      frequency: "2-4주 간격",
      details: "가장 확실한 규칙은 '긴가민가할 때는 주지 않는다'입니다. 흙 깊은 안쪽까지 완전히 먼지처럼 바짝 말랐을 때 물을 줍니다. 추운 겨울철에는 생장 활동이 거의 멈추므로 한두 번 정도로 횟수를 대폭 줄여야 과습으로 인한 무름병을 방지할 수 있습니다."
    },
    sunlight: {
      quality: "매우 높은 환경 적응성 (음지부터 밝은 간접광까지 모두 가능)",
      details: "거의 모든 광량 환경에서 장기간 끈질기게 생존합니다. 방구석의 다소 어두운 그늘진 테이블에서도 살 수 있으나, 더 생생하고 선명한 노란 무늬 테두리와 튼튼한 잎 칼날 형태를 늘리려면 간접 자연광이 드는 밝은 장소가 좋습니다."
    },
    temperature: {
      range: "12°C - 32°C (55°F - 90°F)",
      details: "놀라운 회복탄력성과 강건함을 지녔지만, 다육질 세포 조직을 가지고 있어 영하 수준에 가까운 10°C 미만의 가혹한 한파에 노출될 시 수분이 얼어 세포막이 붕괴하고 잎이 힘없이 주저앉을 수 있습니다."
    },
    humidity: {
      level: "낮음에서 보통",
      details: "일반적인 실내 공기 습도로도 충분합니다. 가습을 지속하는 욕실 구석이나 매일 집중적인 분무질은 잎 사이 주머니 틈새에 물을 가 가두어 곰팡이 감염 등으로 썩게 만드는 원인이 됩니다."
    },
    soil: {
      type: "배수가 매우 빠른 모래 및 다육식물 전용 토양",
      details: "물이 고이지 않고 순식간에 흘러내리는 다공성 흙이 필수적입니다. 일반 분갈이 흙에 모래, 펄라이트, 화산석 배양토 등을 50% 이상 혼합하여 건조한 사막의 지반 환경을 구현해주면 배수 안전망이 완벽히 가동됩니다."
    },
    fertilizing: {
      frequency: "연 2회 공급",
      details: "성장력이 돋보이는 늦봄과 한여름 사이에 전용 다육식물용 영양 희석액을 아주 연하게 타서 흙에 공급합니다. 낙엽이지고 휴면을 취하는 가을과 겨울에는 절대 급여하지 마십시오."
    },
    careSchedule: [
      { action: "물주기", frequency: "격주 또는 매월", instructions: "흙 깊숙한 구역을 미세 가늘게 찔러 보아 사막 모래처럼 건조함이 만연할 때에만 비로소 수분을 보충합니다." },
      { action: "잎사귀 먼지 제거", frequency: "매월", instructions: "넙적한 칼날 잎을 마른 극세사 천으로 가볍게 쓸어내어 미려한 녹색 가로줄 무늬의 광택을 보호해 줍니다." },
      { action: "배수 확인", frequency: "수시", instructions: "물주기 완료 후 화분 받침 saucers 부근에 잔여 고인물이 절대 남아있지 않도록 즉시 비워줍니다." }
    ],
    commonProblems: [
      { problem: "쪼글쪼글하고 구부러지는 잎사귀", symptom: "잎사귀 단면이 입체감을 잃고 쭈글쭈글해지며 한 방향으로 휘거나 힘없이 처집니다.", solution: "만성적인 물부족입니다. 가뭄에 강하지만 식물 내부 수분이 완전히 소진된 것으로, 세면대에 담가 촉촉하게 뿌리 관수를 수시간 해 주면 48시간 내 복구됩니다." },
      { problem: "밑동 밑부분 주저앉음", symptom: "지면과 맞닿은 잎 밑 부분이 거무스름하고 끈적거리며 주저앉아서 쓰러집니다.", solution: "심각한 과습 무름증입니다. 즉시 손상된 잎과 뿌리를 잘라내어 버리고, 생존 흔적 부위를 소독한 흙으로 이식해 흙을 바짝 건조하게 케어합니다." }
    ],
    tips: [
      "무거운 토분이나 테라코타 화분을 추천합니다! 점토 재질은 플라스틱보다 통기성이 탁월하여 과습을 예방하고, 키가 크고 묵직한 잎이 자라더라도 화분이 엎어지는 불상사를 막아줍니다.",
      "물꽂이를 통해 잎 하나로 무한 번식이 가능합니다! 생생한 잎 하나를 골라 약 10cm 크기로 V자 형상 컷팅 후 물에 담궈 두면, 수 주일 후 뿌리가 힘차게 차오릅니다."
    ]
  },
  "Echeveria elegans": {
    commonName: "에케베리아 다육이 (멕시칸 스노우볼)",
    scientificName: "Echeveria elegans",
    family: "Crassulaceae (돌나물과)",
    confidence: 96,
    difficulty: "Easy",
    toxicity: "독성이 전혀 없으며 고양이, 개, 아이 모두에게 완벽하게 무해하여 안심하고 키울 수 있는 식물입니다.",
    description: "멕시칸 스노우볼로도 사랑받는 이 콤팩트한 사막 식물은 은은한 하늘빛과 도톰한 입사귀가 촘촘하여 마치 살아있는 장미꽃 로제트 형상을 발달시킵니다. 계절의 온도가 급격히 바뀌거나 충분한 광합성을 거칠 때 입사귀 끝자락이 복숭아빛 핑크림으로 붉어지는 기막힌 은혜가 일어납니다.",
    watering: {
      frequency: "10-14일 간격",
      details: "소크 앤 드라이 (Soak-and-Dry) 전법을 적용합니다. 흙이 밑구멍까지 완전히 보송하게 말라버린 것을 확인한 한 뒤 흠뻑 관수하되, 절대로 로제트 장미 잎 정중앙의 오목한 중심부에 물방울이 맺힌 채 방치되면 안 됩니다. 고인 물로 인하여 잎들이 속절없이 녹아내려 자멸합니다."
    },
    sunlight: {
      quality: "밝은 직사광선 (하루 최소 4-6시간 이상)",
      details: "해가 하루 종일 들이치는 남향 베란다 화분대나 가장 햇살이 잘 드는 창틀 배치가 무조건 필수적입니다. 조도가 약한 음지에 두면, 앙증맞은 동심원 형태의 로제트가 위로 볼품없이 비쭉 길쭉하게 길어지며 무늬가 흐려지는 도장(웃자람, Etiolation) 현상이 바로 일어납니다."
    },
    temperature: {
      range: "10°C - 27°C (50°F - 80°F)",
      details: "따뜻하고 건조한 기후에 최적화되어 있습니다. 영상 4°C 미만의 매서운 혹한의 실외 날씨에 노출되면 다육질 잎 속의 수분이 얼어 세포가 파괴되므로 속치마를 입혀 따뜻한 내부로 피신시켜야 합니다."
    },
    humidity: {
      level: "낮음",
      details: "매우 건조하고 통풍이 솔솔 잘 통하는 위치가 최적입니다. 대기 중의 습도가 높은 욕실이나 공기 가습기의 직접적 분사는 다육 잎을 불려 흐물흐물하게 만들고 성장을 망치므로 절대 금물입니다."
    },
    soil: {
      type: "굵은 마사토 및 다육 전용 척박한 마사토 믹스",
      details: "순식간에 수분이 비워지는 탁월한 통기성이 전부입니다. 일반 검은 흙 50%에 마사토, 세립 황석, 질석, 난석 등 단단한 광물성 모래 배양토를 50% 이상 아낌없이 뭉개 섞어 과습이 올 틈새를 차단합니다."
    },
    fertilizing: {
      frequency: "연 1회 시비",
      details: "새싹이 돋는 초봄 무렵에 아주 연하게 물에 섞은 다육이용 비료를 흙에 한 차례 공급하는 것으로 충분합니다. 척박한 바위틈에서 자라던 품종으로 과도한 질소 비료는 모양을 뒤틀리게 비정상적으로 키울 뿐입니다."
    },
    careSchedule: [
      { action: "물주기", frequency: "약 10일 간격", instructions: "화분 내부 흙 전체가 바짝 건조해졌다면 샤워기로 흙에만 정중하게 drench 줍니다. 절대 잎 위에 분무하지 마세요." },
      { action: "화분 로테이션", frequency: "매주", instructions: "골고루 대칭인 로제트 꽃 장미 수형을 완성하기를 원한다면, 일주일에 한 번씩 화분을 180도 돌려 햇빛 방향을 고루 분포시킵니다." },
      { action: "하엽 정돈", frequency: "상시", instructions: "목대로 자라나면서 화분 바닥면에 붙은 노랗게 시들어 바들바들 말라버린 하엽들을 핀셋 등으로 정밀하고 부드럽게 떼내어 청결히 치료합니다." }
    ],
    commonProblems: [
      { problem: "도장 현상 (웃자람)", symptom: "로제트 장미 조직이 위로 길게 웃 자라 벌어지며, 잎 사이 간격이 휑하고 넓어져 듬성듬성해집니다.", solution: "햇빛 부족의 적신호입니다. 즉시 가장 햇살이 넘실거리는 선샤인 창문 명당으로 긴급 피신해 줍니다. 심하면 윗머리를 소독용 칼로 똑 떼내어 적심 삽목을 추진합니다." },
      { problem: "반투명 무름 잎 현상", symptom: "단단했던 잎이 물풍선처럼 노랗고 말랑말랑한 반투명으로 연해지며 톡 건드려도 우수수 힘없이 낙엽처럼 낙과합니다.", solution: "충격적인 과습 상태입니다. 물주기를 즉시 정지하고 화분을 온전히 통풍이 잘되는 뜨거운 햇볕 속에 건조시키며 상황에 따라 분갈이를 실시해 뿌리를 꺼내어 환기시킵니다." }
    ],
    tips: [
      "잎장 하나로 아기가 탄생합니다! 건강한 밑잎을 비틀어 상처 한 점 없이 깔끔한 생장점을 포함하여 떼어낸 뒤, 약 사흘간 말린 뒤 비옥하고 살균된 다육 흙 위에 눕혀놓기만 하면 앙증맞은 자구가 우뚝 튀어나옵니다.",
      "잎을 손가락으로 손쓸수록 아름다움이 깎입니다! 건강하게 만발한 에케베리아 표면의 보얀 흰 가루는 먼지가 아니고 자외선과 뜨거움을 물리치고자 분비되는 뽀얀 Farina 왁스 보호막이므로 소중히 아껴주세요."
    ]
  }
};

export function getLocalizedPlantData(plant: PlantData, language: "en" | "ko"): PlantData {
  if (language === "en") return plant;
  const key = Object.keys(KOREAN_SAMPLES_MAP).find(
    k => k.toLowerCase() === plant.scientificName.toLowerCase()
  );
  if (key) {
    return {
      ...KOREAN_SAMPLES_MAP[key],
      confidence: plant.confidence,
    };
  }
  return plant;
}

