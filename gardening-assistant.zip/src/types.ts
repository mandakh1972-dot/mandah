export interface WaterSoilConfig {
  frequency: string;
  details: string;
}

export interface SunTempHumidityConfig {
  quality?: string;
  range?: string;
  level?: string;
  details: string;
}

export interface CareTask {
  action: string;
  frequency: string;
  instructions: string;
}

export interface PlantDiagnosis {
  problem: string;
  symptom: string;
  solution: string;
}

export interface PlantData {
  commonName: string;
  scientificName: string;
  family: string;
  confidence: number;
  description: string;
  difficulty: "Easy" | "Medium" | "Hard" | string;
  toxicity: string;
  watering: {
    frequency: string;
    details: string;
  };
  sunlight: {
    quality: string;
    details: string;
  };
  temperature: {
    range: string;
    details: string;
  };
  humidity: {
    level: string;
    details: string;
  };
  soil: {
    type: string;
    details: string;
  };
  fertilizing: {
    frequency: string;
    details: string;
  };
  careSchedule: CareTask[];
  commonProblems: PlantDiagnosis[];
  tips: string[];
}

export interface CareLogEntry {
  id: string;
  date: string;
  action: string;
  notes: string;
}

export interface SavedPlant {
  id: string;
  customName: string;
  photoBase64: string; // Captured / uploaded image
  addedAt: string;
  plantData: PlantData;
  careLogs: CareLogEntry[];
  lastWatered: string | null; // ISO Date String
  nextWatered: string | null; // ISO Date String
  waterIntervalDays: number; // e.g. 7
}

export interface Message {
  id: string;
  role: "user" | "bot";
  text: string;
  timestamp: string;
}
