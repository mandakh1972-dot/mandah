import React, { useState, useEffect } from "react";
import { 
  Leaf, 
  Droplet, 
  Sun, 
  Thermometer, 
  ShieldAlert, 
  MessageSquare, 
  Plus, 
  Trash2, 
  Compass, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  LogOut, 
  Send,
  User,
  Activity,
  Award,
  ChevronRight,
  Info
} from "lucide-react";
import PlantIdentifier from "./components/PlantIdentifier";
import { PlantData, SavedPlant, CareLogEntry, Message } from "./types";
import { SAMPLES, getLocalizedPlantData } from "./utils/samples";

const T = {
  en: {
    appSubtitle: "Computer-vision plant diagnostics and garden log workspace",
    gardenSizeLabel: "Garden Size:",
    specimensUnit: "Specimens",
    tasksPendingPrefix: "tasks pending today",
    activeGardenTitle: "My Active Garden Log",
    activeGardenSubtitle: "Water and inspect your saved indoor plants",
    plantsUnit: "Plants",
    emptyGardenTitle: "Your garden is empty",
    emptyGardenDesc: "Identify water/cactus plants or select a sample above to build your track ledger.",
    countdownToday: "Water TODAY",
    countdownOverdue: "d overdue",
    countdownDays: "days",
    countdownDay: "day",
    countdownIn: "In",
    countdownNoSchedule: "No schedule",
    deletePlantTitle: "Delete plant",
    safeSpecies: "SAFE SPECIES",
    toxicWarning: "TOXIC WARNING",
    petCompatibility: "Pet Compatibility",
    idealTemperature: "Ideal Temperature",
    relativeHumidity: "Relative Humidity",
    substrateSoil: "Substrate Soil Composition",
    fertilizerRoutine: "Fertilizer Routine",
    humidityDemands: "demands",
    aiGeneratedCredits: "AI generated botanical insights • models/gemini-3.5-flash",
    trackingActive: "Overdue threshold tracking active",
    proTipsHeader: "Horticulture Pro-Tips",
    staticTip: "Wipe foliage with lukewarm damp cloth quarterly for maximum solar intake.",
    careScheduleHeader: "Interactive Care Schedule Tasks",
    logDoneBtn: "Log Done",
    diagnosticHeader: "Diagnostic Illness Guidelines",
    symptomTag: "Symptom",
    cureMethodLabel: "Cure Method:",
    botHeaderTitle: "Interactive Botanist Bot",
    botGroundsSuffix: "Grounds answers in",
    botGroundsTraits: "traits",
    botWritingResponse: "Writing response...",
    chatInputPlaceholder: "Ask about pruning, brown tip cure, propagation...",
    careLogHeader: "Garden Care Log History",
    careLogSub: "View past watering steps and custom journal logs",
    writeJournalLabel: "Write Journal Entry",
    writeJournalPlaceholder: "Repotted mix / pruning notes",
    recordPressEnter: "Press Enter to record instantly",
    logBtn: "Log",
    selectPlantFallbackText: "Select a plant in your garden list to view or write care log histories.",
    noSpecimenActiveTitle: "No specimen active",
    noSpecimenActiveDesc: "Scan your house plants using the tool at the left, or view an instant pre-loaded sample.",
    plantTaxonomy: "Plant Taxonomy",
    botanicalApi: "Botanical API",
    securityRules: "Security Rules",
    copyrightText: "© 2026 Gardening Assistant & Verdant Bento Lab. All rights of AI modeling reserved.",
    savingBtn: "Save",
    saveLabel: "Assign Nickname & Save to Monitor",
    matchConfidenceLabel: "match confidence",
    expertSampleLabel: "Expert Sample",
    careLevelLabel: "Care Level",
    savedInGardenLabel: "Saved in digital garden log",
    enterNicknamePlaceholder: "Enter nickname (e.g. Penny)",
    hydrationLabel: "Hydration",
    luminanceLabel: "Luminance",
    waterScheduleLabel: "Water Schedule",
    sunlightLevelLabel: "Sunlight Level",
    defaultWelcomeMsg: "Hello! I am your AI Botanical Consultant. Identify a plant or choose one from your digital garden, and I can answer precise questions about its biology, propagation, and troubleshooting.",
    wateringAction: "Watering",
    discoveryNoteAction: "Discovery Note",
    discoveryNoteAdded: 'Added "{nickname}" to the garden workspace.',
    wateringLogNotes: "Gave full drench with room temperature water. Soil dampness checked.",
    alertTaskLogged: 'Completed task logged in custom logs below: "{action}"',
    chatSwitchMsg: 'Now advising on your "{customName}" ({scientificName}). Ask me about its watering routine, specific health indicators, or propagating new leaves!',
    chatIdentifiedMsg: 'Success! I have identified the specimen as {commonName} ({scientificName}) with {confidence}% confidence score. View its personalized care schedules below or ask me any dynamic care questions!',
    switchOutputKo: "Switch output mode to Korean (한국어 번역)",
    switchOutputEn: "Switch output mode to English"
  },
  ko: {
    appSubtitle: "컴퓨터 비전 식물 진단 및 정원 로그 워크스페이스",
    gardenSizeLabel: "정원 크기:",
    specimensUnit: "개 표본",
    tasksPendingPrefix: "개 작업 대기 중",
    activeGardenTitle: "나의 활성 정원 일지",
    activeGardenSubtitle: "저장된 실내 식물 물주기 및 점검",
    plantsUnit: "개 식물",
    emptyGardenTitle: "정원이 비어 있습니다",
    emptyGardenDesc: "식물 사진을 식별하거나 위의 샘플을 선택하여 관리 대장을 만들어 보세요.",
    countdownToday: "오늘 물주기",
    countdownOverdue: "일 지남",
    countdownDays: "일",
    countdownDay: "일",
    countdownIn: "",
    countdownNoSchedule: "일정 없음",
    deletePlantTitle: "식물 삭제",
    safeSpecies: "안전한 종",
    toxicWarning: "독성 경고",
    petCompatibility: "반려동물 호환성",
    idealTemperature: "이상적인 온도",
    relativeHumidity: "상대 습도",
    substrateSoil: "용토 흙 구성",
    fertilizerRoutine: "비료 주기 루틴",
    humidityDemands: "필요",
    aiGeneratedCredits: "AI 분석 식물 통찰 • models/gemini-3.5-flash",
    trackingActive: "지연 시간 감지 모니터링 활성화",
    proTipsHeader: "예술 정원 가꾸기 허브 팁",
    staticTip: "광합성 효과를 위해 매 분기마다 미지근한 젖은 천으로 잎을 닦아주세요.",
    careScheduleHeader: "대화형 관리 스케줄 일정",
    logDoneBtn: "완료 기록",
    diagnosticHeader: "진단 질병 지침 가이드",
    symptomTag: "증상",
    cureMethodLabel: "치료법:",
    botHeaderTitle: "대화형 식물학 AI 챗봇",
    botGroundsSuffix: "의 특성에 기인한 정밀 조언",
    botGroundsTraits: "",
    botWritingResponse: "답변 작성 중...",
    chatInputPlaceholder: "가지치기, 갈색 잎 치료, 번식 등에 관해 질문해보세요...",
    careLogHeader: "정원 관리 로그 히스토리",
    careLogSub: "과거 물주기 단계 및 기입된 정원 일지 열람",
    writeJournalLabel: "수동 일지 작성",
    writeJournalPlaceholder: "분갈이 믹스 / 가지치기 메모 기입",
    recordPressEnter: "엔터를 눌러 즉시 기록 저장",
    logBtn: "기록",
    selectPlantFallbackText: "관리 로그 기록을 열람하거나 작성하려면 정원 리스트에서 식물을 선택하세요.",
    noSpecimenActiveTitle: "활성화된 식물이 없습니다",
    noSpecimenActiveDesc: "왼쪽 툴을 사용하여 실내 식물을 스캔하거나, 미리 준비된 샘플을 확인해보세요.",
    plantTaxonomy: "식물 분류학",
    botanicalApi: "식물 API",
    securityRules: "보안 규칙",
    copyrightText: "© 2026 Gardening Assistant & Verdant Bento Lab. 모든 권리 보유.",
    savingBtn: "저장",
    saveLabel: "닉네임 지정 및 모니터링 저장",
    matchConfidenceLabel: "일치 신뢰도",
    expertSampleLabel: "학술용 샘플",
    careLevelLabel: "관리 난이도",
    savedInGardenLabel: "디지털 정원에 저장됨",
    enterNicknamePlaceholder: "닉네임 입력 (예: 페니)",
    hydrationLabel: "수분 공급",
    luminanceLabel: "조도",
    waterScheduleLabel: "물주기 일정",
    sunlightLevelLabel: "햇빛 수준",
    defaultWelcomeMsg: "안녕하세요! 저는 귀하의 AI 식물학 컨설턴트입니다. 정원의 식물을 스캔하거나 샘플을 지정하여 건강 상태 분석, 물주기, 배양 관련 정밀 조언을 받아보세요.",
    wateringAction: "물주기",
    discoveryNoteAction: "발견 일지",
    discoveryNoteAdded: '"{nickname}" 식물을 정원 워크스페이스에 추가했습니다.',
    wateringLogNotes: "실온의 물로 흠뻑 주었습니다. 토양 수분 상태 점검 필.",
    alertTaskLogged: '스케줄 과업이 아래 맞춤 및 커스텀 로그에 기록되었습니다: "{action}"',
    chatSwitchMsg: '"{customName}" ({scientificName}) 식물의 관리 관리 조언 정보가 활성화되었습니다. 물주기 일정, 생장 징후 대처 요령에 대해 물어보세요!',
    chatIdentifiedMsg: '식별에 성공했습니다! 식물은 {commonName} ({scientificName}) 이며, 신뢰도는 {confidence}%입니다. 아래에서 관리 정보를 보거나 질문해 주세요!',
    switchOutputKo: "동작 방식을 한국어 모드로 전환합니다",
    switchOutputEn: "동작 방식을 영어 모드로 전환합니다"
  }
};

export default function App() {

  const [activePlant, setActivePlant] = useState<PlantData | null>(null);
  const [activePhoto, setActivePhoto] = useState<string | null>(null);
  const [activeConfidence, setActiveConfidence] = useState<number | null>(null);
  
  // Support language translation (English & Korean)
  const [language, setLanguage] = useState<"en" | "ko">("en");

  // Custom Garden state (persisted using localStorage)
  const [savedGarden, setSavedGarden] = useState<SavedPlant[]>([]);
  const [selectedGardenPlantId, setSelectedGardenPlantId] = useState<string | null>(null);
  const [newCustomName, setNewCustomName] = useState("");
  const [isAddingToGarden, setIsAddingToGarden] = useState(false);

  // Chat/Advice Bot states
  const [chatMessages, setChatMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "bot",
      text: "Hello! I am your AI Botanical Consultant. Identify a plant or choose one from your digital garden, and I can answer precise questions about its biology, propagation, and troubleshooting.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [currentQuery, setCurrentQuery] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Load digital garden lists from localStorage on mount
  useEffect(() => {
    const cachedGarden = localStorage.getItem("verdant_garden_list");
    if (cachedGarden) {
      try {
        const decoded = JSON.parse(cachedGarden);
        setSavedGarden(decoded);
        if (decoded.length > 0) {
          // Select first plant as active on start
          const first = decoded[0];
          setSelectedGardenPlantId(first.id);
          setActivePlant(first.plantData);
          setActivePhoto(first.photoBase64);
          setActiveConfidence(first.plantData.confidence);
        } else {
          // Fallback static sample Monstera on first visit
          const monsteraSample = SAMPLES[0];
          setActivePlant(monsteraSample.plantData);
          const svgBase64 = btoa(unescape(encodeURIComponent(monsteraSample.svgMarkup)));
          setActivePhoto(`data:image/svg+xml;base64,${svgBase64}`);
          setActiveConfidence(monsteraSample.plantData.confidence);
        }
      } catch (e) {
        console.error("Cache parsing error:", e);
      }
    } else {
      // Default initial state matching the Swiss Cheese sample for immediate beautiful Bento preview
      const monsteraSample = SAMPLES[0];
      setActivePlant(monsteraSample.plantData);
      const svgBase64 = btoa(unescape(encodeURIComponent(monsteraSample.svgMarkup)));
      setActivePhoto(`data:image/svg+xml;base64,${svgBase64}`);
      setActiveConfidence(monsteraSample.plantData.confidence);
    }
  }, []);

  // Save digital garden state to localStorage whenever modified
  const saveGardenToStorage = (newGarden: SavedPlant[]) => {
    setSavedGarden(newGarden);
    localStorage.setItem("verdant_garden_list", JSON.stringify(newGarden));
  };

  // Switch active viewed plant when a garden item is clicked
  const handleSelectGardenPlant = (plant: SavedPlant) => {
    setSelectedGardenPlantId(plant.id);
    setActivePlant(plant.plantData);
    setActivePhoto(plant.photoBase64);
    setActiveConfidence(plant.plantData.confidence);
    
    // Smooth reset chat with welcome referencing this plant
    const localizedData = getLocalizedPlantData(plant.plantData, language);
    setChatMessages([
      {
        id: "switch-msg",
        role: "bot",
        text: T[language].chatSwitchMsg
          .replace("{customName}", plant.customName)
          .replace("{scientificName}", localizedData.scientificName),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // Trigger when PlantIdentifier yields results
  const handlePlantIdentified = (data: PlantData, imageBase64: string) => {
    setActivePlant(data);
    setActivePhoto(imageBase64);
    setActiveConfidence(data.confidence);
    setSelectedGardenPlantId(null); // Clear active garden select to offer saving

    const localizedData = getLocalizedPlantData(data, language);
    setChatMessages(prev => [
      ...prev,
      {
        id: `id-chat-${Date.now()}`,
        role: "bot",
        text: T[language].chatIdentifiedMsg
          .replace("{commonName}", localizedData.commonName)
          .replace("{scientificName}", localizedData.scientificName)
          .replace("{confidence}", String(data.confidence)),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // Add currently viewed plant to personal digital garden list
  const handleSaveToGarden = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePlant || !activePhoto) return;

    const localizedData = getLocalizedPlantData(activePlant, language);
    const nickname = newCustomName.trim() || localizedData.commonName;
    const intervalDays = activePlant.commonName.toLowerCase().includes("snake") ? 21 : 
                         activePlant.commonName.toLowerCase().includes("succulent") ? 12 : 7;

    const today = new Date();
    const nextWatering = new Date();
    nextWatering.setDate(today.getDate() + intervalDays);

    const newPlantInstance: SavedPlant = {
      id: `saved-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      customName: nickname,
      photoBase64: activePhoto,
      addedAt: today.toISOString(),
      plantData: activePlant,
      careLogs: [
        {
          id: `log-${Date.now()}`,
          date: today.toISOString().split("T")[0],
          action: T[language].discoveryNoteAction,
          notes: T[language].discoveryNoteAdded.replace("{nickname}", nickname)
        }
      ],
      lastWatered: today.toISOString(),
      nextWatered: nextWatering.toISOString(),
      waterIntervalDays: intervalDays
    };

    const updated = [newPlantInstance, ...savedGarden];
    saveGardenToStorage(updated);
    setSelectedGardenPlantId(newPlantInstance.id);
    setNewCustomName("");
    setIsAddingToGarden(false);
  };

  // Delete a plant from digital garden
  const handleDeleteFromGarden = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedGarden.filter(item => item.id !== id);
    saveGardenToStorage(updated);
    if (selectedGardenPlantId === id) {
      setSelectedGardenPlantId(null);
      if (updated.length > 0) {
        handleSelectGardenPlant(updated[0]);
      }
    }
  };

  // Log a manual watering event
  const handleWaterPlant = (id: string) => {
    const updated = savedGarden.map(plant => {
      if (plant.id === id) {
        const today = new Date();
        const nextDate = new Date();
        nextDate.setDate(today.getDate() + plant.waterIntervalDays);

        const newLog: CareLogEntry = {
          id: `log-water-${Date.now()}`,
          date: today.toISOString().split("T")[0],
          action: T[language].wateringAction,
          notes: T[language].wateringLogNotes
        };

        return {
          ...plant,
          lastWatered: today.toISOString(),
          nextWatered: nextDate.toISOString(),
          careLogs: [newLog, ...plant.careLogs]
        };
      }
      return plant;
    });

    saveGardenToStorage(updated);
    // Sync UI view state if looking at the watered plant
    const target = updated.find(p => p.id === id);
    if (target) {
      setActivePlant(target.plantData);
    }
  };

  // Add custom manual journal/log text entries
  const handleAddCustomLog = (id: string, actionType: string, notesText: string) => {
    if (!notesText.trim()) return;

    const updated = savedGarden.map(plant => {
      if (plant.id === id) {
        const today = new Date();
        const newLog: CareLogEntry = {
          id: `log-cust-${Date.now()}`,
          date: today.toISOString().split("T")[0],
          action: actionType,
          notes: notesText
        };
        return {
          ...plant,
          careLogs: [newLog, ...plant.careLogs]
        };
      }
      return plant;
    });

    saveGardenToStorage(updated);
  };

  // Send chatbot query
  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentQuery.trim()) return;

    const userMsg: Message = {
      id: `chat-usr-${Date.now()}`,
      role: "user",
      text: currentQuery,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    const inputMsg = currentQuery;
    setCurrentQuery("");
    setIsChatLoading(true);

    try {
      // Build previous 5 messages for brief history context
      const miniHistory = chatMessages.slice(-5).map(m => ({
        role: m.role === "user" ? "user" : "model",
        text: m.text
      }));

      const response = await fetch("/api/chat-advice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: inputMsg,
          history: miniHistory,
          plantContext: activePlant,
          language: language
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned error status ${response.status}`);
      }

      const reply = await response.json();
      
      setChatMessages(prev => [
        ...prev,
        {
          id: `chat-bot-${Date.now()}`,
          role: "bot",
          text: reply.text || "I apologize, I didn't catch that. Could you describe your plant query again?",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err: any) {
      console.error("Chat error:", err);
      setChatMessages(prev => [
        ...prev,
        {
          id: `chat-err-${Date.now()}`,
          role: "bot",
          text: `Disconnected. Please make sure GEMINI_API_KEY is configured correctly. ${err.message || ""}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Helper code to analyze water countdown
  const getWateringCountdown = (plant: SavedPlant, lang: "en" | "ko" = language) => {
    if (!plant.nextWatered) return T[lang].countdownNoSchedule;
    const nextDate = new Date(plant.nextWatered);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    nextDate.setHours(0, 0, 0, 0);

    const diffTime = nextDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return T[lang].countdownToday;
    if (diffDays < 0) return `${Math.abs(diffDays)}${T[lang].countdownOverdue}`;
    if (lang === "ko") return `${diffDays}${T[lang].countdownDays} 후`;
    return `${T[lang].countdownIn} ${diffDays} ${diffDays > 1 ? T[lang].countdownDays : T[lang].countdownDay}`;
  };

  const localizedActivePlant = activePlant ? getLocalizedPlantData(activePlant, language) : null;

  return (
    <div className="min-h-[100vh] bg-[#F7F9F5] flex flex-col p-4 md:p-8 font-sans text-[#2D332B] selection:bg-[#E9EDC9]/60 selection:text-[#1A2E1D]" id="root-bento-container">
      
      {/* Decorative Aurora backdrop effects */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#A3B18A]/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute top-2/3 right-1/4 w-[400px] h-[400px] bg-[#E9EDC9]/20 rounded-full blur-[160px] pointer-events-none -z-10" />

      {/* Styled Premium Header */}
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-5" id="heading-block-verdant">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-[#3A5A40] rounded-2xl flex items-center justify-center text-white shadow-md shadow-[#3A5A40]/10 transition-transform hover:rotate-6">
            <Leaf className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold tracking-tight text-[#1A2E1D]">Verdant.AI</span>
              <span className="px-2.5 py-0.5 bg-[#E9EDC9] text-[#3A5A40] text-[10px] font-black rounded-full uppercase tracking-[0.1em]">Bento Pro</span>
            </div>
            <p className="text-xs text-[#5C6658]">{T[language].appSubtitle}</p>
          </div>
        </div>

        {/* Dynamic Translation Selector */}
        <div className="flex bg-white/90 backdrop-blur-sm border border-[#E5EADF] p-1 rounded-2xl shadow-sm text-xs font-semibold gap-1" id="language-toggle-bar">
          <button
            onClick={() => setLanguage("ko")}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              language === "ko"
                ? "bg-[#3A5A40] text-white shadow-sm shadow-[#3A5A40]/25"
                : "text-[#5C6658] hover:text-[#1A2E1D] hover:bg-neutral-100"
            }`}
            title="한국어 모드로 변경"
          >
            <span className="text-sm">🇰🇷</span>
            <span>Korean (한국어)</span>
          </button>
          <button
            onClick={() => setLanguage("en")}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              language === "en"
                ? "bg-[#3A5A40] text-white shadow-sm shadow-[#3A5A40]/25"
                : "text-[#5C6658] hover:text-[#1A2E1D] hover:bg-neutral-100"
            }`}
            title="Switch to English"
          >
            <span className="text-sm">🇺🇸</span>
            <span>English (영어)</span>
          </button>
        </div>

        {/* Global metadata log counters */}
        <div className="flex items-center gap-4 text-xs font-medium text-[#5C6658]">
          <div className="bg-white/80 border border-[#E5EADF] px-4 py-2 rounded-2xl flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span>{T[language].gardenSizeLabel} <b>{savedGarden.length}</b> {T[language].specimensUnit}</span>
          </div>
          {savedGarden.length > 0 && (
            <div className="bg-[#FEFAE0] border border-[#E9EDC9] px-4 py-2 rounded-2xl flex items-center gap-2 text-[#7c2d12]">
              <Calendar className="w-3.5 h-3.5" />
              <span>{savedGarden.filter(p => p.nextWatered && new Date(p.nextWatered) <= new Date()).length} {T[language].tasksPendingPrefix}</span>
            </div>
          )}
        </div>
      </header>

      {/* Primary Bento Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 w-full max-w-7xl mx-auto" id="bento-grid-workspace">
        
        {/* LEFT COLUMN (lg:col-span-4): Inputs & Log lists */}
        <div className="lg:col-span-4 flex flex-col gap-6" id="bento-sidebar-left">
          
          {/* Main Photo Scanner Panel */}
          <div className="bg-white rounded-[32px] shadow-sm border border-[#E5EADF] overflow-hidden p-6 relative">
            <PlantIdentifier onPlantIdentified={handlePlantIdentified} language={language} />
          </div>

          {/* Digital Garden List */}
          <div className="bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF] flex flex-col min-h-[300px]">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-base font-bold text-[#1A2E1D] flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#3A5A40]" />
                  {T[language].activeGardenTitle}
                </h3>
                <p className="text-xs text-[#5C6658]">{T[language].activeGardenSubtitle}</p>
              </div>
              <span className="text-xs px-2 py-0.5 bg-[#F0F2EE] font-semibold text-[#5C6658] rounded-md">
                {savedGarden.length} {T[language].plantsUnit}
              </span>
            </div>

            {savedGarden.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-[#F7F9F5]/80 border border-dashed border-[#E5EADF] rounded-[24px]">
                <div className="w-12 h-12 bg-[#FEFAE0] text-[#B08968] rounded-full flex items-center justify-center mb-3">
                  <Compass className="w-6 h-6 animate-spin-slow" />
                </div>
                <p className="text-xs font-bold text-[#1A2E1D]">{T[language].emptyGardenTitle}</p>
                <p className="text-[11px] text-[#5C6658] mt-1 max-w-[200px] mx-auto">{T[language].emptyGardenDesc}</p>
              </div>
            ) : (
              <div className="space-y-3 overflow-y-auto max-h-[320px] pr-1">
                {savedGarden.map((item) => {
                  const isActive = selectedGardenPlantId === item.id;
                  const daysLeft = getWateringCountdown(item);
                  const isOverdue = daysLeft.includes("overdue") || daysLeft.includes("TODAY") || daysLeft.includes("지남") || daysLeft.includes("오늘");
                  const itemLocalized = getLocalizedPlantData(item.plantData, language);
                  const displayCustomName = item.customName === item.plantData.commonName ? itemLocalized.commonName : item.customName;

                  return (
                    <div
                      key={item.id}
                      onClick={() => handleSelectGardenPlant(item)}
                      className={`group p-3 rounded-[20px] border transition-all cursor-pointer flex items-center justify-between ${
                        isActive
                          ? "bg-[#3A5A40] border-[#3A5A40] text-white shadow-md shadow-[#3A5A40]/10"
                          : "bg-[#F7F9F5] hover:bg-white border-[#E5EADF] hover:shadow-sm"
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Little plant preview */}
                        <div className="w-11 h-11 rounded-xl overflow-hidden bg-white/90 border border-neutral-200/40 p-1 flex items-center justify-center shrink-0">
                          {item.photoBase64.startsWith("data:image/svg+xml") ? (
                            <div 
                              className="w-full h-full scale-[1.2]"
                              dangerouslySetInnerHTML={{ __html: atob(item.photoBase64.split(",")[1]) }}
                            />
                          ) : (
                            <img src={item.photoBase64} alt={displayCustomName} className="w-full h-full object-cover rounded-lg" referrerPolicy="no-referrer" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold truncate">{displayCustomName}</p>
                          <p className={`text-[10px] truncate ${isActive ? "text-[#A3B18A]" : "text-[#5C6658] italic"}`}>
                            {itemLocalized.scientificName}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* Quick Action water tap */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleWaterPlant(item.id);
                          }}
                          className={`p-1.5 rounded-lg transition-all active:scale-90 ${
                            isActive 
                              ? "bg-white/20 hover:bg-white/30 text-white" 
                              : "bg-[#E9EDC9] hover:bg-[#A3B18A] text-[#3A5A40] hover:text-white"
                          }`}
                          title="Instant water drench trigger"
                        >
                          <Droplet className="w-3.5 h-3.5" />
                        </button>
                        
                        {/* Countdown Pill */}
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${
                          isActive 
                             ? "bg-white/10 text-white" 
                             : isOverdue 
                               ? "bg-red-50 text-red-600 border border-red-100" 
                               : "bg-[#E5EADF] text-[#3A5A40]"
                        }`}>
                          {daysLeft}
                        </span>

                        <button
                          onClick={(e) => handleDeleteFromGarden(item.id, e)}
                          className={`p-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity ${
                            isActive ? "hover:text-red-300 text-white/60" : "hover:text-red-600 text-neutral-400"
                          }`}
                          title={T[language].deletePlantTitle}
                        >
                          <Trash2 className="w-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>


        {/* RIGHT FULL BENTO COLUMN (lg:col-span-8): Selected Specimen Display */}
        <div className="lg:col-span-8 flex flex-col gap-6" id="bento-workspace-main">
          
          {localizedActivePlant ? (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 w-full">
              
              {/* Card 1: Header / Title Profile Match Banner */}
              <div className="col-span-12 bg-[#3A5A40] rounded-[32px] p-6 md:p-8 text-white relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                
                {/* Visual decor */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-[#A3B18A]/20 rounded-full blur-3xl pointer-events-none" />

                <div className="relative z-10 flex items-center gap-5">
                  <div className="w-16 h-16 rounded-[20px] bg-white/10 border border-white/20 p-2 flex items-center justify-center shrink-0 shadow-inner overflow-hidden">
                    {activePhoto ? (
                      activePhoto.startsWith("data:image/svg+xml") ? (
                        <div 
                          className="w-full h-full scale-[1.3]"
                          dangerouslySetInnerHTML={{ __html: atob(activePhoto.split(",")[1]) }}
                        />
                      ) : (
                        <img src={activePhoto} alt={localizedActivePlant.commonName} className="w-full h-full object-cover rounded-xl" referrerPolicy="no-referrer" />
                      )
                    ) : (
                      <Leaf className="w-8 h-8 text-[#A3B18A]" />
                    )}
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-black tracking-tight">{localizedActivePlant.commonName}</h2>
                    <p className="text-[#A3B18A] text-xs font-mono mt-0.5">
                      {localizedActivePlant.scientificName} • Family: <span className="underline italic">{localizedActivePlant.family}</span>
                    </p>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="px-2.5 py-0.5 bg-white/15 text-white rounded-full text-[10px] font-bold">
                        {activeConfidence ? `${activeConfidence}% ${T[language].matchConfidenceLabel}` : T[language].expertSampleLabel}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        localizedActivePlant.difficulty === "Easy" || localizedActivePlant.difficulty === "쉬움" ? "bg-emerald-500/20 text-emerald-300" :
                        localizedActivePlant.difficulty === "Medium" || localizedActivePlant.difficulty === "보통" ? "bg-amber-500/20 text-amber-300" : "bg-rose-500/20 text-rose-300"
                      }`}>
                        {localizedActivePlant.difficulty} {T[language].careLevelLabel}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="relative z-10 flex gap-2 w-full md:w-auto shrink-0">
                  {selectedGardenPlantId ? (
                    <div className="flex gap-2 items-center">
                      <span className="text-[11px] font-bold text-[#A3B18A] flex items-center gap-1.5 bg-neutral-900/35 px-3 py-2 rounded-full border border-white/10">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        {T[language].savedInGardenLabel}
                      </span>
                    </div>
                  ) : (
                    <div className="w-full">
                      {isAddingToGarden ? (
                        <form onSubmit={handleSaveToGarden} className="flex gap-2 w-full bg-white/10 p-1 rounded-xl border border-white/20 backdrop-blur">
                          <input
                            type="text"
                            placeholder={T[language].enterNicknamePlaceholder}
                            required
                            value={newCustomName}
                            onChange={(e) => setNewCustomName(e.target.value)}
                            className="bg-transparent border-none text-white text-xs px-3 focus:ring-0 w-40 outline-none placeholder:text-white/50"
                          />
                          <button
                            type="submit"
                            className="bg-white hover:bg-[#E9EDC9] text-[#3A5A40] text-xs font-bold px-4 py-2 rounded-lg transition-colors shrink-0"
                          >
                            {T[language].savingBtn}
                          </button>
                        </form>
                      ) : (
                        <button
                          onClick={() => setIsAddingToGarden(true)}
                          className="w-full px-5 py-3 bg-[#A3B18A] hover:bg-[#A3B18A]/90 text-[#1A2E1D] hover:scale-103 font-bold rounded-2xl text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 duration-200"
                        >
                          <Plus className="w-4 h-4 shrink-0" />
                          {T[language].saveLabel}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>


              {/* Card 2: Watering metrics dashboard widget */}
              <div className="col-span-12 md:col-span-4 bg-[#E9EDC9] rounded-[32px] p-6 flex flex-col justify-between border border-[#CCD5AE] hover:shadow-md transition-shadow group">
                <div className="flex justify-between items-start">
                  <div className="w-10 h-10 bg-white/60 group-hover:bg-white rounded-2xl flex items-center justify-center text-[#3A5A40] transition-colors shadow-sm">
                    <Droplet className="w-5 h-5" />
                  </div>
                  <span className="text-[9px] font-bold text-[#3A5A40] bg-[#CCD5AE]/40 px-2.5 py-0.5 rounded-full uppercase tracking-wider">{T[language].hydrationLabel}</span>
                </div>
                <div className="mt-6">
                  <p className="text-[10px] font-bold text-[#3A5A40]/60 uppercase tracking-widest leading-none">{T[language].waterScheduleLabel}</p>
                  <p className="text-xl font-extrabold text-[#1A2E1D] mt-1">{localizedActivePlant.watering?.frequency}</p>
                  <p className="text-xs text-[#5C6658] mt-1.5 leading-snug line-clamp-2" title={localizedActivePlant.watering?.details}>
                    {localizedActivePlant.watering?.details}
                  </p>
                </div>
              </div>


              {/* Card 3: Sunlight parameters widget */}
              <div className="col-span-12 md:col-span-4 bg-[#FEFAE0] rounded-[32px] p-6 flex flex-col justify-between border border-[#E9EDC9] hover:shadow-md transition-shadow group">
                <div className="flex justify-between items-start">
                  <div className="w-10 h-10 bg-white/80 group-hover:bg-white rounded-2xl flex items-center justify-center text-[#B08968] transition-colors shadow-sm">
                    <Sun className="w-5 h-5" />
                  </div>
                  <span className="text-[9px] font-bold text-[#B08968] bg-[#E9EDC9]/50 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-mono">{T[language].luminanceLabel}</span>
                </div>
                <div className="mt-6">
                  <p className="text-[10px] font-bold text-[#B08968] uppercase tracking-widest leading-none">{T[language].sunlightLevelLabel}</p>
                  <p className="text-xl font-extrabold text-[#1A2E1D] mt-1">{localizedActivePlant.sunlight?.quality}</p>
                  <p className="text-xs text-[#5C6658] mt-1.5 leading-snug line-clamp-3" title={localizedActivePlant.sunlight?.details}>
                    {localizedActivePlant.sunlight?.details}
                  </p>
                </div>
              </div>


              {/* Card 4: Toxicity Pet Warning Check */}
              <div className="col-span-12 md:col-span-4 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF] flex flex-col justify-between hover:shadow-md transition-shadow group">
                <div className="flex justify-between items-start">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-colors shadow-sm ${
                    localizedActivePlant.toxicity.toLowerCase().includes("toxic to cats") || localizedActivePlant.toxicity.toLowerCase().includes("toxic to dogs") || localizedActivePlant.toxicity.includes("독성")
                      ? "bg-rose-50 text-rose-600 group-hover:bg-rose-100" 
                      : "bg-emerald-50 text-emerald-600 group-hover:bg-emerald-100"
                  }`}>
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-md ${
                    localizedActivePlant.toxicity.toLowerCase().includes("toxic to cats") || localizedActivePlant.toxicity.toLowerCase().includes("toxic to dogs") || localizedActivePlant.toxicity.includes("독성")
                      ? "bg-rose-50 text-red-600 border border-red-200" 
                      : "bg-emerald-50 text-emerald-600 border border-emerald-200"
                  }`}>
                    {localizedActivePlant.toxicity.toLowerCase().includes("toxic") || localizedActivePlant.toxicity.includes("독성") ? T[language].toxicWarning : T[language].safeSpecies}
                  </span>
                </div>
                <div className="mt-4">
                  <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest leading-none">{T[language].petCompatibility}</p>
                  <p className="text-xs text-[#5C6658] mt-2 leading-relaxed">
                    {localizedActivePlant.toxicity}
                  </p>
                </div>
              </div>


              {/* Card 5: Core Detailed Care Guidelines */}
              <div className="col-span-12 md:col-span-8 bg-white rounded-[32px] p-6 md:p-8 shadow-sm border border-[#E5EADF] flex flex-col justify-between">
                <div>
                  <h4 className="text-base font-bold text-[#1A2E1D] mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-[#3A5A40]" />
                    {language === "ko" ? "필수 보타니컬 식물 관리 가이드" : "Essential Botanical Care Reference"}
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
                    
                    <div className="flex gap-3">
                      <div className="p-2 bg-[#F7F9F5] rounded-xl text-[#3A5A40] h-9 w-9 flex items-center justify-center shrink-0">
                        <Thermometer className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-[#3A5A40]">{T[language].idealTemperature}</p>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{localizedActivePlant.temperature?.range}</p>
                        <p className="text-[11px] text-[#5C6658] mt-1 font-sans">{localizedActivePlant.temperature?.details}</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="p-2 bg-[#FEFAE0] rounded-xl text-[#B08968] h-9 w-9 flex items-center justify-center shrink-0">
                        <Compass className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-[#B08968]">{T[language].relativeHumidity}</p>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{localizedActivePlant.humidity?.level} {T[language].humidityDemands}</p>
                        <p className="text-[11px] text-[#5C6658] mt-1 leading-snug">{localizedActivePlant.humidity?.details}</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="p-2 bg-[#F7F9F5] rounded-xl text-[#3A5A40] h-9 w-9 flex items-center justify-center shrink-0">
                        <Leaf className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-[#3A5A40]">{T[language].substrateSoil}</p>
                        <p className="text-[11px] text-neutral-400 mt-0.5">{localizedActivePlant.soil?.type}</p>
                        <p className="text-[11px] text-[#5C6658] mt-1 leading-snug">{localizedActivePlant.soil?.details}</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="p-2 bg-[#E9EDC9] rounded-xl text-[#3A5A40] h-9 w-9 flex items-center justify-center shrink-0">
                        <Droplet className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-bold text-[#3A5A40]">{T[language].fertilizerRoutine}</p>
                        <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">{localizedActivePlant.fertilizing?.frequency}</p>
                        <p className="text-[11px] text-[#5C6658] mt-1 leading-snug">{localizedActivePlant.fertilizing?.details}</p>
                      </div>
                    </div>

                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-[#F0F2EE] flex flex-wrap justify-between items-center gap-3">
                  <span className="text-[10px] text-[#A3B18A] font-mono italic">
                    {T[language].aiGeneratedCredits}
                  </span>
                  
                  <div className="bg-[#F7F9F5] px-3.5 py-1.5 rounded-full border border-[#E5EADF]">
                    <span className="text-[11px] font-bold text-[#3A5A40] flex items-center gap-1">
                      <Info className="w-3.5 h-3.5" />
                      {T[language].trackingActive}
                    </span>
                  </div>
                </div>
              </div>


              {/* Card 6: Bullet list of Pro tips */}
              <div className="col-span-12 md:col-span-4 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF] flex flex-col justify-between">
                <div>
                  <h4 className="text-sm font-black text-[#1A2E1D] mb-3 uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="text-[#3A5A40] w-4 h-4 shrink-0 animate-pulse" />
                    {T[language].proTipsHeader}
                  </h4>
                  <div className="space-y-3">
                    {localizedActivePlant.tips?.slice(0, 3).map((tip, i) => (
                      <div key={i} className="flex gap-2.5 items-start">
                        <span className="text-[#3A5A40] font-black text-xs font-mono mt-0.5">#{i+1}</span>
                        <p className="text-xs text-[#5C6658] leading-tight font-sans">{tip}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Internal static display note */}
                <div className="mt-4 pt-3 border-t border-[#F0F2EE]">
                  <p className="text-[10px] text-neutral-400 italic">
                    {T[language].staticTip}
                  </p>
                </div>
              </div>


              {/* Card 7: Care To-do Schedule checklists */}
              <div className="col-span-12 md:col-span-6 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF]">
                <h4 className="text-sm font-black text-[#1A2E1D] mb-4 uppercase tracking-wider flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#3A5A40]" />
                  {T[language].careScheduleHeader}
                </h4>
                <div className="space-y-3.5">
                  {localizedActivePlant.careSchedule?.map((task, idx) => (
                    <div key={idx} className="p-3 bg-[#F7F9F5] rounded-2xl border border-[#E5EADF] flex justify-between items-start gap-3 hover:translate-x-1 transition-all">
                      <div className="flex gap-2.5">
                        <div className="w-2 h-2 rounded-full bg-[#A3B18A] mt-1.5 shrink-0" />
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-xs text-[#3A5A40]">{task.action}</p>
                            <span className="text-[9px] bg-[#E9EDC9] px-2 py-0.5 rounded-full text-[#3A5A40] font-medium">
                              {task.frequency}
                            </span>
                          </div>
                          <p className="text-[11px] text-[#5C6658] mt-1 leading-snug">{task.instructions}</p>
                        </div>
                      </div>

                      {selectedGardenPlantId && (
                        <button
                          onClick={() => {
                            handleAddCustomLog(
                              selectedGardenPlantId,
                              task.action,
                              `Completed: ${task.instructions}`
                            );
                            alert(T[language].alertTaskLogged.replace("{action}", task.action));
                          }}
                          className="px-3 py-1 bg-white hover:bg-[#3A5A40] text-[#3A5A40] hover:text-white border border-[#E5EADF] rounded-lg text-[9px] font-bold transition-all active:scale-95"
                        >
                          {T[language].logDoneBtn}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>


              {/* Card 8: Common problems Diagnostic lookup list */}
              <div className="col-span-12 md:col-span-6 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF]">
                <h4 className="text-sm font-black text-rose-700 mb-4 uppercase tracking-wider flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                  {T[language].diagnosticHeader}
                </h4>
                <div className="space-y-3">
                  {localizedActivePlant.commonProblems?.map((prob, index) => (
                    <div key={index} className="p-3 rounded-2xl bg-rose-50/40 border border-rose-100 flex flex-col gap-1.5">
                      <div className="flex justify-between items-center">
                        <p className="text-xs font-bold text-[#1A2E1D]">{prob.problem}</p>
                        <span className="text-[9px] text-rose-600 font-bold bg-white px-2 py-0.5 rounded border border-rose-100 uppercase">
                          {T[language].symptomTag}
                        </span>
                      </div>
                      <p className="text-xs text-rose-800 leading-normal italic bg-white/70 p-2 rounded-lg border border-rose-50">
                        "{prob.symptom}"
                      </p>
                      <p className="text-xs text-neutral-600 mt-0.5 pl-1.5 border-l-2 border-[#A3B18A]">
                        <span className="font-bold text-neutral-800">{T[language].cureMethodLabel}</span> {prob.solution}
                      </p>
                    </div>
                  ))}
                </div>
              </div>


              {/* Card 9: Live Botanical Chat Advisor */}
              <div className="col-span-12 md:col-span-7 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF] flex flex-col h-[400px]">
                <div className="flex justify-between items-center mb-4 pb-3 border-b border-[#F0F2EE]">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-[#E5EADF] flex items-center justify-center text-[#3A5A40]">
                      <MessageSquare className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#1A2E1D]">{T[language].botHeaderTitle}</h4>
                      <p className="text-[10px] text-[#A3B18A] font-medium leading-none mt-0.5">
                        {T[language].botGroundsSuffix} {localizedActivePlant.scientificName} {T[language].botGroundsTraits}
                      </p>
                    </div>
                  </div>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                </div>

                {/* Chat transcript block */}
                <div className="flex-1 overflow-y-auto space-y-3.5 pr-2 mb-4 scroll-smooth">
                  {chatMessages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={`flex gap-2 w-full max-w-[85%] ${
                        msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-[10px] select-none ${
                        msg.role === "user" ? "bg-[#3A5A40] text-white" : "bg-[#E5EADF] text-[#3A5A40]"
                      }`}>
                        {msg.role === "user" ? <User className="w-3 h-3" /> : <Leaf className="w-3 h-3" />}
                      </div>

                      <div className={`p-3 rounded-2xl text-xs leading-relaxed ${
                        msg.role === "user" 
                          ? "bg-[#3A5A40] text-white rounded-tr-none" 
                          : "bg-[#F7F9F5] text-[#2D332B] rounded-tl-none border border-[#E5EADF]"
                      }`}>
                        <p>{msg.id === "welcome" ? T[language].defaultWelcomeMsg : msg.text}</p>
                        <span className={`text-[9px] block text-right mt-1 ${
                          msg.role === "user" ? "text-white/60" : "text-neutral-400"
                        }`}>
                          {msg.timestamp}
                        </span>
                      </div>
                    </div>
                  ))}

                  {isChatLoading && (
                    <div className="flex gap-2 mr-auto items-center">
                      <div className="w-6 h-6 rounded-full bg-[#E5EADF] flex items-center justify-center animate-bounce">
                        <Leaf className="w-3 h-3 text-[#3A5A40]" />
                      </div>
                      <div className="bg-[#F7F9F5] p-3 rounded-2xl text-xs text-neutral-400 italic">
                        {T[language].botWritingResponse}
                      </div>
                    </div>
                  )}
                </div>

                {/* Input form */}
                <form onSubmit={handleSendChat} className="flex gap-2 bg-[#F7F9F5] p-1 rounded-2xl border border-[#E5EADF]">
                  <input
                    type="text"
                    required
                    placeholder={T[language].chatInputPlaceholder}
                    disabled={isChatLoading}
                    value={currentQuery}
                    onChange={(e) => setCurrentQuery(e.target.value)}
                    className="flex-grow bg-transparent border-none text-xs px-3 focus:ring-0 outline-none text-[#2D332B] placeholder:text-neutral-400"
                  />
                  <button
                    type="submit"
                    disabled={isChatLoading || !currentQuery.trim()}
                    className="p-2.5 bg-[#3A5A40] hover:bg-[#3A5A40]/90 text-white rounded-xl transition-all disabled:opacity-40 shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>


              {/* Card 10: Garden Care Log History entries */}
              <div className="col-span-12 md:col-span-5 bg-white rounded-[32px] p-6 shadow-sm border border-[#E5EADF] flex flex-col h-[400px]">
                <h4 className="text-xs font-black text-[#1A2E1D] mb-2 uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#3A5A40]" />
                  {T[language].careLogHeader}
                </h4>
                <p className="text-[11px] text-[#5C6658] mb-4">{T[language].careLogSub}</p>

                {selectedGardenPlantId ? (
                  <div className="flex-grow flex flex-col justify-between">
                    {/* Add quick manual log input */}
                    <div className="bg-[#F7F9F5] p-3 rounded-2xl border border-[#E5EADF] mb-4">
                      <p className="text-[10px] font-black text-[#3A5A40] uppercase tracking-wider mb-2">{T[language].writeJournalLabel}</p>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          id="custom-log-notes-input"
                          placeholder={T[language].writeJournalPlaceholder}
                          className="bg-white border border-[#E5EADF] rounded-xl text-xs px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#3A5A40] flex-grow text-[#2D332B]"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              const input = e.currentTarget;
                              handleAddCustomLog(selectedGardenPlantId, language === "ko" ? "일반 관리" : "General Care", input.value);
                              input.value = "";
                            }
                          }}
                        />
                        <button
                          onClick={() => {
                            const input = document.getElementById("custom-log-notes-input") as HTMLInputElement;
                            if (input && input.value) {
                              handleAddCustomLog(selectedGardenPlantId, language === "ko" ? "일반 관리" : "General Care", input.value);
                              input.value = "";
                            }
                          }}
                          className="bg-[#3A5A40] hover:bg-[#3A5A40]/90 text-white text-[10px] font-bold px-3 py-1.5 rounded-xl transition-colors"
                        >
                          {T[language].logBtn}
                        </button>
                      </div>
                      <p className="text-[9px] text-[#A3B18A] mt-1.5 italic">{T[language].recordPressEnter}</p>
                    </div>

                    {/* Care logs timeline list */}
                    <div className="flex-1 overflow-y-auto space-y-3 max-h-[160px] pr-1">
                      {savedGarden.find(p => p.id === selectedGardenPlantId)?.careLogs.map((log) => (
                        <div key={log.id} className="p-2.5 rounded-xl bg-[#F7F9F5] border border-[#E5EADF] text-[11px] hover:bg-neutral-50/50 transition-colors">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-[#3A5A40] text-xs">
                              {log.action}
                            </span>
                            <span className="text-[9px] text-[#A3B18A] font-semibold">{log.date}</span>
                          </div>
                          <p className="text-neutral-600 mt-1">{log.notes}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-[#F7F9F5]/50 border border-dashed border-[#E5EADF] rounded-2l">
                    <p className="text-xs text-[#5C6658] max-w-[200px]">
                      {T[language].selectPlantFallbackText}
                    </p>
                  </div>
                )}
              </div>

            </div>
          ) : (
            <div className="w-full flex-1 flex flex-col items-center justify-center p-12 text-center bg-white rounded-[40px] shadow-sm border border-[#E5EADF] min-h-[480px]">
              <div className="w-16 h-16 bg-[#FEFAE0] rounded-full flex items-center justify-center text-[#B08968] mb-4">
                <Compass className="w-8 h-8 animate-spin-slow" />
              </div>
              <h2 className="text-xl font-bold text-[#1A2E1D]">{T[language].noSpecimenActiveTitle}</h2>
              <p className="text-sm text-[#5C6658] mt-1 max-w-[320px] mx-auto">
                {T[language].noSpecimenActiveDesc}
              </p>
            </div>
          )}

        </div>

      </div>

      {/* Styled Footer */}
      <footer className="mt-16 text-center text-[11px] text-[#A3B18A] border-t border-[#E5EADF] pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 max-w-7xl w-full mx-auto">
        <p>{T[language].copyrightText}</p>
        <div className="flex gap-4">
          <a href="#" className="hover:text-[#3A5A40] transition-colors">{T[language].plantTaxonomy}</a>
          <a href="#" className="hover:text-[#3A5A40] transition-colors">{T[language].botanicalApi}</a>
          <a href="#" className="hover:text-[#3A5A40] transition-colors">{T[language].securityRules}</a>
        </div>
      </footer>

    </div>
  );
}
