import React, { useState, useRef, useEffect } from "react";
import { Camera, Upload, RefreshCw, Heart, AlertCircle, Sparkles } from "lucide-react";
import { SAMPLES, SamplePlant } from "../utils/samples";
import { PlantData } from "../types";

interface PlantIdentifierProps {
  onPlantIdentified: (data: PlantData, imageBase64: string) => void;
  language: "en" | "ko";
}

export default function PlantIdentifier({ onPlantIdentified, language }: PlantIdentifierProps) {
  const [dragActive, setDragActive] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  
  // Camera States
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  // General States
  const [isLoading, setIsLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Translation helpers
  const t = {
    title: language === "ko" ? "식물 AI 실시간 식별" : "Identify Fresh Plant",
    subtitle: language === "ko" ? "실시간 사진을 찍거나 이미지를 업로드하여 전문가용 분석을 받으세요" : "Capture a live photo or upload an image to diagnose instantly",
    invalidFile: language === "ko" ? "올바른 이미지 파일(PNG/JPEG)을 업로드해주세요." : "Please select a valid image file (PNG/JPEG).",
    captureBtn: language === "ko" ? "촬영하기" : "Capture Photo",
    cancelBtn: language === "ko" ? "취소" : "Cancel",
    analyzeBtn: language === "ko" ? "Gemini 인공지능 분석 요청하기" : "Request Diagnosis from Gemini",
    dragLabel: language === "ko" ? "이곳에 식물 사진을 끌어다 놓으세요" : "Drag and drop plant photo here",
    browseLabel: language === "ko" ? "또는 클릭하여 기기 사진 라이브러리 탐색" : "or click to browse your local files",
    cameraBtn: language === "ko" ? "웹 세션 카메라 피드 연결" : "Use Web Camera Feed",
    consulting: language === "ko" ? "식물 식별 및 분석 병리학적 자문 진행 중..." : "Consulting Botany Database...",
    consultingSub: language === "ko" ? "엽록체 형태, 잎맥 패턴 및 토양 수분 진단 분석 중" : "Analyzing morphology, foliage pattern, and soil diagnosis",
    sampleLabel: language === "ko" ? "또는 미리 준비된 학술용 샘플 선택" : "Or try a pre-loaded botanical sample",
    noImgErr: language === "ko" ? "이미지를 선택하거나 사진을 먼저 촬영해주세요." : "Please select a file or take a photo first.",
    cameraAccessErr: language === "ko" ? "카메라 장치에 연결할 수 없습니다. 권한 승인을 확인하거나 수동 업로드를 사용해 주세요." : "Could not access camera. Please confirm permissions or upload an image file instead.",
  };

  // Stop camera when component unmounts
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  // Handle Drag Events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setAnalysisError(t.invalidFile);
      return;
    }
    setAnalysisError(null);
    setImageFile(file);
    setIsCameraActive(false);

    // Stop stream if active
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setPreviewUrl(result);
      const base64Content = result.split(",")[1];
      setImageBase64(base64Content);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Start Camera Stream
  const startCamera = async () => {
    setCameraError(null);
    setIsCameraActive(true);
    setPreviewUrl(null);
    setImageFile(null);
    setImageBase64(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error("Camera error:", err);
      setIsCameraActive(false);
      setCameraError("Could not access camera. Please confirm permissions or upload an image file instead.");
    }
  };

  // Capture Frame from Camera
  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement("canvas");
      // Match high quality sizing
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
        setPreviewUrl(dataUrl);
        const base64Data = dataUrl.split(",")[1];
        setImageBase64(base64Data);
        
        // Turn off camera
        if (cameraStream) {
          cameraStream.getTracks().forEach(track => track.stop());
          setCameraStream(null);
        }
        setIsCameraActive(false);
      }
    }
  };

  // Reset Identifier
  const handleReset = () => {
    setImageFile(null);
    setPreviewUrl(null);
    setImageBase64(null);
    setAnalysisError(null);
    setCameraError(null);
    setIsCameraActive(false);
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
  };

  // Load a Pre-loaded Sample
  const handleSelectSample = (sample: SamplePlant) => {
    handleReset();
    setIsLoading(true);
    setAnalysisError(null);

    // Simulate analyzing a sample for premium instant rendering
    setTimeout(() => {
      // Create a nice inline SVG placeholder for their photo so it flows into their garden log perfectly
      const svgBase64 = btoa(unescape(encodeURIComponent(sample.svgMarkup)));
      const inlineSvgUrl = `data:image/svg+xml;base64,${svgBase64}`;
      onPlantIdentified(sample.plantData, inlineSvgUrl);
      setIsLoading(false);
    }, 1200);
  };

  // Send Custom Upload to Server-side Gemini API
  const handleAnalyzePhoto = async () => {
    if (!imageBase64) {
      setAnalysisError(t.noImgErr);
      return;
    }

    setIsLoading(true);
    setAnalysisError(null);

    try {
      const response = await fetch("/api/identify-plant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: imageBase64,
          mimeType: imageFile?.type || "image/jpeg",
          language: language,
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const plantData: PlantData = await response.json();
      onPlantIdentified(plantData, previewUrl || "");
    } catch (error: any) {
      console.error("Analysis failure:", error);
      setAnalysisError(error.message || (language === "ko" ? "식물 식별에 실패했습니다. 사진이 선명한지 확인한 후 다시 시도해보세요." : "Failed to identify plant. Please make sure the photo is clear and try again."));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full relative rounded-2xl overflow-hidden glass-card border border-neutral-800 bg-neutral-900/60 p-6 md:p-8 flex flex-col justify-between min-h-[480px]" id="plant-identifier-container">
      
      {/* Dynamic Background Aurora Glows */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10">
        {/* Component Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gradient-to-tr from-emerald-400 to-teal-400 rounded-xl text-neutral-900 shadow-md">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">{t.title}</h2>
            <p className="text-xs text-neutral-400">{t.subtitle}</p>
          </div>
        </div>

        {/* Error Messages */}
        {(cameraError || analysisError) && (
          <div className="mb-4 p-4 bg-red-950/40 border border-red-800/60 text-red-200 rounded-xl flex items-start gap-3 text-sm">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{analysisError || cameraError}</p>
          </div>
        )}

        {/* Upload Canvas / Camera Area */}
        <div 
          className={`relative border-2 border-dashed rounded-xl transition-all duration-300 min-h-[260px] flex flex-col items-center justify-center p-4 ${
            dragActive ? "border-emerald-400 bg-emerald-950/10" : "border-neutral-800 bg-neutral-950/45 hover:border-neutral-700"
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          {isCameraActive ? (
            <div className="w-full h-full flex flex-col items-center justify-center">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full max-h-[300px] object-cover rounded-lg bg-black border border-neutral-800 mb-4"
              />
              <div className="flex gap-3">
                <button 
                  onClick={capturePhoto}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-400 to-cyan-400 text-neutral-950 rounded-lg hover:brightness-110 active:scale-95 transition-all text-xs font-semibold flex items-center gap-2 shadow-lg shadow-emerald-500/20"
                >
                  <Camera className="w-4 h-4" />
                  {t.captureBtn}
                </button>
                <button 
                  onClick={handleReset}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs rounded-lg active:scale-95 transition-all"
                >
                  {t.cancelBtn}
                </button>
              </div>
            </div>
          ) : previewUrl ? (
            <div className="w-full flex flex-col items-center justify-center py-4">
              <div className="relative w-44 h-44 rounded-xl overflow-hidden border border-neutral-700 shadow-xl mb-4 bg-neutral-900 flex items-center justify-center">
                {/* Check if it's an inline SVG simulated URL or real photo */}
                {previewUrl.startsWith("data:image/svg+xml") ? (
                  <div 
                    className="w-full h-full p-4 flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: atob(previewUrl.split(",")[1]) }}
                  />
                ) : (
                  <img src={previewUrl} alt="Plant Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                )}
                
                <button 
                  onClick={handleReset}
                  className="absolute bottom-2 right-2 p-2 bg-neutral-950/80 hover:bg-neutral-950 text-red-400 rounded-lg border border-neutral-800 transition-all active:scale-90"
                  title="Remove Image"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {!isLoading && (
                <button
                  onClick={handleAnalyzePhoto}
                  className="px-6 py-3 bg-gradient-to-r from-emerald-400 vi-teal-400 to-cyan-400 text-neutral-950 font-bold text-sm rounded-xl hover:brightness-110 active:scale-98 transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20"
                >
                  <Sparkles className="w-4 h-4 animate-spin-slow" />
                  {t.analyzeBtn}
                </button>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center p-6 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleFileChange}
              />
              <div className="w-14 h-14 bg-neutral-900 rounded-full border border-neutral-800 flex items-center justify-center mb-4 text-neutral-400 group-hover:text-neutral-200">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-white mb-1">{t.dragLabel}</p>
              <p className="text-xs text-neutral-500 mb-6">{t.browseLabel}</p>
              
              <button 
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  startCamera();
                }}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded-lg active:scale-95 transition-all flex items-center gap-2 border border-neutral-700"
              >
                <Camera className="w-3.5 h-3.5 text-neutral-400" />
                {t.cameraBtn}
              </button>
            </div>
          )}

          {/* Loading Animation overlay */}
          {isLoading && (
            <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center transition-all">
              <div className="relative flex items-center justify-center w-16 h-16 mb-4">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-500/20" />
                <div className="absolute inset-0 rounded-full border-4 border-t-emerald-400 border-r-cyan-400 animate-spin" />
                <Heart className="w-6 h-6 text-emerald-400 animate-pulse" />
              </div>
              <p className="text-sm font-semibold text-white tracking-wide animate-pulse">{t.consulting}</p>
              <p className="text-xs text-neutral-400 mt-1 max-w-[200px] text-center leading-normal">{t.consultingSub}</p>
            </div>
          )}
        </div>
      </div>

      {/* Pre-installed Botanical Samples Catalog for Instant sandbox trials */}
      <div className="mt-8 relative z-10 border-t border-neutral-800 pt-6">
        <p className="text-xs font-semibold text-emerald-400 mb-3 tracking-wider uppercase">{t.sampleLabel}</p>
        <div className="grid grid-cols-3 gap-3">
          {SAMPLES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => handleSelectSample(sample)}
              disabled={isLoading}
              className="flex flex-col items-center bg-neutral-950/50 hover:bg-neutral-950 hover:scale-103 border border-neutral-800/80 hover:border-emerald-500/40 p-3 rounded-xl transition-all text-center leading-tight active:scale-97 disabled:opacity-50"
            >
              <div className="w-12 h-12 bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 flex items-center justify-center mb-2 overflow-hidden">
                <div className="w-full h-full scale-[1.3] flex items-center justify-center" dangerouslySetInnerHTML={{ __html: sample.svgMarkup }} />
              </div>
              <span className="text-[11px] font-bold text-neutral-100 line-clamp-1">{sample.name}</span>
              <span className="text-[9px] text-neutral-500 mt-0.5 font-mono italic">{sample.difficulty}</span>
            </button>
          ))}
        </div>
      </div>

    </div>
  );
}
