import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// High limit to support transferring captured photos in base64 format safely
app.use(express.json({ limit: "25mb" }));

// Lazy Gemni client initialization to prevent crash if environment setup is in progress
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is not defined in the environment. Please configure it in your Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. Endpoint for identifying plant via a photo (Base64)
app.post("/api/identify-plant", async (req, res): Promise<any> => {
  try {
    const { imageBase64, mimeType, language } = req.body;

    if (!imageBase64 || !mimeType) {
      return res.status(400).json({ error: "Missing imageBase64 or mimeType data." });
    }

    const ai = getGeminiClient();

    const imagePart = {
      inlineData: {
        mimeType: mimeType, // e.g. "image/jpeg", "image/png"
        data: imageBase64,
      },
    };

    const targetLanguageInstruction = language === "ko" 
      ? "\nCRITICAL: Respond with all descriptive text values translated into fluent, natural Korean (한국어). The 'commonName' must be the popular Korean name for this plant. Complete detail fields: 'description', 'difficulty', 'toxicity', 'watering' (frequency, details), 'sunlight' (quality, details), 'temperature', 'humidity', 'soil', 'fertilizing', 'careSchedule', 'commonProblems', 'tips' MUST be written in Korean. 'scientificName' can remain standard botanical Latin."
      : "\nRespond in English.";

    const promptText = `
      You are an expert botanist and horticulturist.
      Analyze the attached plant image. Identify the plant and provide comprehensive, practical care instructions.
      Respond ONLY in structured JSON matching the requested schema. If the image does not show a plant, or is not clear enough, please still provide a best-effort response but lower the confidence percentage and explain in the description.
      ${targetLanguageInstruction}
    `;

    const textPart = {
      text: promptText,
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: [
            "commonName",
            "scientificName",
            "family",
            "confidence",
            "description",
            "difficulty",
            "toxicity",
            "watering",
            "sunlight",
            "temperature",
            "humidity",
            "soil",
            "fertilizing",
            "careSchedule",
            "commonProblems",
            "tips",
          ],
          properties: {
            commonName: {
              type: Type.STRING,
              description: "The primary or most popular common name of the plant.",
            },
            scientificName: {
              type: Type.STRING,
              description: "The botanical/scientific name of the plant.",
            },
            family: {
              type: Type.STRING,
              description: "The botanical family details.",
            },
            confidence: {
              type: Type.INTEGER,
              description: "Your identification confidence score from 0 to 100.",
            },
            description: {
              type: Type.STRING,
              description: "A friendly, detailed 2-3 sentence overview of this plant's personality and characteristics.",
            },
            difficulty: {
              type: Type.STRING,
              description: "Care level difficulty: 'Easy', 'Medium', or 'Hard'.",
            },
            toxicity: {
              type: Type.STRING,
              description: "Toxicity to pets (dogs/cats) and humans. Be explicit.",
            },
            watering: {
              type: Type.OBJECT,
              required: ["frequency", "details"],
              properties: {
                frequency: {
                  type: Type.STRING,
                  description: "Summary frequency, e.g., 'Every 7-10 days', 'When soil is completely dry'.",
                },
                details: {
                  type: Type.STRING,
                  description: "Detailed practical watering instructions including testing soil moisture.",
                },
              },
            },
            sunlight: {
              type: Type.OBJECT,
              required: ["quality", "details"],
              properties: {
                quality: {
                  type: Type.STRING,
                  description: "Summary light requirements, e.g., 'Bright, indirect light', 'Low light tolerant'.",
                },
                details: {
                  type: Type.STRING,
                  description: "Helpful tips on where to place the plant inside or outside the house.",
                },
              },
            },
            temperature: {
              type: Type.OBJECT,
              required: ["range", "details"],
              properties: {
                range: {
                  type: Type.STRING,
                  description: "Ideal temperature scale, e.g., '18°C - 24°C (65°F - 75°F)'.",
                },
                details: {
                  type: Type.STRING,
                  description: "Advice on winter cold drafts or excess heat protection.",
                },
              },
            },
            humidity: {
              type: Type.OBJECT,
              required: ["level", "details"],
              properties: {
                level: {
                  type: Type.STRING,
                  description: "Humidity demands: 'Low', 'Average', or 'High'.",
                },
                details: {
                  type: Type.STRING,
                  description: "Practical suggestions: misting, pebble trays, or humidifiers.",
                },
              },
            },
            soil: {
              type: Type.OBJECT,
              required: ["type", "details"],
              properties: {
                type: Type.STRING,
                description: "Type of potting mix, e.g., 'Well-draining, peat-based mix with perlite'.",
                details: {
                  type: Type.STRING,
                  description: "Pot size details, drainage necessity, or soil repotting guidance.",
                },
              },
            },
            fertilizing: {
              type: Type.OBJECT,
              required: ["frequency", "details"],
              properties: {
                frequency: {
                  type: Type.STRING,
                  description: "E.g., 'Once a month during spring and summer'.",
                },
                details: {
                  type: Type.STRING,
                  description: "Tips on fertilizer dilution, organic vs synthetic options.",
                },
              },
            },
            careSchedule: {
              type: Type.ARRAY,
              description: "A list of upcoming specific care tasks to keep this plant thriving.",
              items: {
                type: Type.OBJECT,
                required: ["action", "frequency", "instructions"],
                properties: {
                  action: {
                    type: Type.STRING,
                    description: "Task keyword, e.g., 'Watering', 'Pruning', 'Fertilizing', 'Shining leaves'.",
                  },
                  frequency: {
                    type: Type.STRING,
                    description: "Frequency label shorthand, e.g., 'Weekly', 'Bi-weekly', 'Twice a year'.",
                  },
                  instructions: {
                    type: Type.STRING,
                    description: "Explicit execution, e.g., 'Trim off yellow trailing vines with sterile shears.'",
                  },
                },
              },
            },
            commonProblems: {
              type: Type.ARRAY,
              description: "A diagnostic lookup of typical complaints.",
              items: {
                type: Type.OBJECT,
                required: ["problem", "symptom", "solution"],
                properties: {
                  problem: {
                    type: Type.STRING,
                    description: "Problem title, e.g., 'Root rot', 'Fungal Gnats', 'Dry leaf tips'.",
                  },
                  symptom: {
                    type: Type.STRING,
                    description: "Visual indicator, e.g., 'Leaves turning mushy and yellow at the base'.",
                  },
                  solution: {
                    type: Type.STRING,
                    description: "How to cure and troubleshoot, e.g., 'Repot immediately into dry soil after washing roots in hydrogen peroxide.'",
                  },
                },
              },
            },
            tips: {
              type: Type.ARRAY,
              description: "A few specialized pro tips for the plant.",
              items: {
                type: Type.STRING,
              },
            },
          },
        },
      },
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response text returned from Gemini API");
    }

    const payload = JSON.parse(resultText);
    res.json(payload);
  } catch (error: any) {
    console.error("Error in /api/identify-plant:", error);
    res.status(500).json({ error: error.message || "An error occurred during plant identification." });
  }
});

// 2. Chatbot Consultation endpoint
app.post("/api/chat-advice", async (req, res): Promise<any> => {
  try {
    const { message, history, plantContext, language } = req.body;

    if (!message) {
      return res.status(400).json({ error: "No message was provided." });
    }

    const ai = getGeminiClient();

    // Prepare systemic prompt including context about relevant plant
    let systemInstruction = "You are a warm, supportive, and extremely knowledgeable Gardening Assistant. Your task is to help the user diagnose plant illnesses, provide care remedies, outline propagation methods, and keep their house plants thriving.";
    if (plantContext) {
      systemInstruction += ` The user is currently asking about their ${plantContext.commonName} (${plantContext.scientificName}), family ${plantContext.family}. It requires difficulty level: ${plantContext.difficulty}. Detail metrics: Watering is ${plantContext.watering?.frequency}, Sunlight is ${plantContext.sunlight?.quality}, Toxicity is ${plantContext.toxicity}. Please ground your advice specifically in the biology of ${plantContext.scientificName}`;
    }

    if (language === "ko") {
      systemInstruction += " CRITICAL: Please reply exclusively in fluent Korean (한국어). Friendly, polite tone (use respectful form - 해요체 or 합쇼체).";
    } else {
      systemInstruction += " Please reply exclusively in English.";
    }

    // Build chat history
    const chat = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    // Feed conversation history to establish state if present
    if (history && Array.isArray(history) && history.length > 0) {
      // Create a list of messages for Gemini. Note that in chat sessions, you can set the state.
      // But we can also compile a list of previous chat history and use the chat.sendMessage as normal.
      // Let's load history into chat. Currently with @google/genai SDK, chat state can be preloaded 
      // by setting the state or simply streaming back-and-forth, or we can use normal format.
      // Let's do a single model turn or pass history with model query for standard approach if necessary.
      // Or we can just use generateContent with the history structured, which is extremely robust!
      // Let's do generateContent since it's fully stateless and works flawlessly without complex chat session bindings.
    }

    // Creating model dialog history format
    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      history.forEach((msg: any) => {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.text }],
        });
      });
    }

    // Add current user message
    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Error in /api/chat-advice:", error);
    res.status(500).json({ error: error.message || "An error occurred during chat consultation." });
  }
});

// Configure Vite or Static Assets depending on runtime mode
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in development mode. Mounting Vite middleware.");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode. Serving static files from dist/.");
    const distPath = path.join(process.cwd(), "dist");
    
    // Serve static files
    app.use(express.static(distPath));
    
    // Serve index.html for SPA client-side router
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Gardening Assistant server is running on http://localhost:${PORT}`);
  });
}

startServer();
